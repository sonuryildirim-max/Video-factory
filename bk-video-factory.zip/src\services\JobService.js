/**
 * Job Service for BK-VF (Bilge Karga Video Factory)
 * Atomic job processing with exponential backoff polling
 * Based on master JSON architecture from conversation with Claude
 */

import { JobRepository } from '../repositories/JobRepository.js';
import { R2Service } from './R2Service.js';
import { LogService } from './LogService.js';
import { CONFIG } from '../config/config.js';

export class JobService {
    constructor(env) {
        this.env = env;
        this.jobRepo = new JobRepository(env);
        this.r2Service = new R2Service(env);
        this.logService = new LogService(env);
    }

    /**
     * Create a new conversion job
     * @param {Object} jobData - Job data
     * @returns {Promise<Object>} Created job
     */
    async createJob(jobData) {
        try {
            // Validate required fields
            if (!jobData.original_name || !jobData.r2_raw_key || !jobData.quality) {
                throw new Error('Missing required fields: original_name, r2_raw_key, quality');
            }

            // Validate r2_raw_key starts with raw-uploads/ (security)
            if (!jobData.r2_raw_key.startsWith('raw-uploads/')) {
                throw new Error('Invalid r2_raw_key: must start with raw-uploads/');
            }

            // Generate clean name (sanitize original name)
            const cleanName = this.sanitizeFilename(jobData.original_name);
            
            // Create job in database
            const job = await this.jobRepo.create({
                original_name: jobData.original_name,
                clean_name: cleanName,
                r2_raw_key: jobData.r2_raw_key,
                quality: jobData.quality,
                file_size_input: jobData.file_size_input || 0,
                uploaded_by: jobData.uploaded_by || 'admin',
                tags: jobData.tags || '',
                project_name: jobData.project_name || '',
                notes: jobData.notes || ''
            });

            // Log job creation
            await this.logService.createJobLog(job.id, 'INFO', 'Job created', 'UPLOAD', {
                original_name: job.original_name,
                clean_name: job.clean_name,
                quality: job.quality
            });

            return job;
        } catch (error) {
            console.error('Error creating job:', error);
            throw error;
        }
    }

    /**
     * Claim a pending job (atomic operation)
     * @param {string} workerId - Worker identifier
     * @returns {Promise<Object|null>} Claimed job or null if no jobs available
     */
    async claimJob(workerId) {
        try {
            // Atomic claim: PENDING → PROCESSING
            const job = await this.jobRepo.claimPendingJob(workerId);
            
            if (!job) {
                return null; // No pending jobs
            }

            // Log job claim
            await this.logService.createJobLog(job.id, 'INFO', 'Job claimed by worker', 'CLAIM', {
                worker_id: workerId,
                started_at: job.started_at
            });

            // Generate presigned URL for raw file download
            const downloadUrl = await this.r2Service.getPresignedDownloadUrl(
                CONFIG.R2_RAW_BUCKET,
                job.r2_raw_key,
                300 // 5 minutes TTL
            );

            return {
                ...job,
                download_url: downloadUrl,
                ffmpeg_preset: this.getFfmpegPreset(job.quality)
            };
        } catch (error) {
            console.error('Error claiming job:', error);
            throw error;
        }
    }

    /**
     * Complete a job
     * @param {number} jobId - Job ID
     * @param {string} workerId - Worker identifier
     * @param {Object} result - Processing result
     * @returns {Promise<Object>} Updated job
     */
    async completeJob(jobId, workerId, result) {
        try {
            // Validate result
            if (!result.public_url) {
                throw new Error('Missing public_url in result');
            }

            // Update job status to COMPLETED
            const job = await this.jobRepo.completeJob(jobId, workerId, {
                public_url: result.public_url,
                file_size_output: result.file_size_output || 0,
                duration: result.duration || 0,
                processing_time_seconds: result.processing_time_seconds || 0,
                resolution: result.resolution || '',
                bitrate: result.bitrate || 0,
                codec: result.codec || 'h264',
                frame_rate: result.frame_rate || 30,
                audio_codec: result.audio_codec || 'aac',
                audio_bitrate: result.audio_bitrate || 128,
                ffmpeg_command: result.ffmpeg_command || '',
                ffmpeg_output: result.ffmpeg_output || ''
            });

            // Log job completion
            await this.logService.createJobLog(jobId, 'INFO', 'Job completed successfully', 'COMPLETE', {
                public_url: result.public_url,
                file_size_output: result.file_size_output,
                processing_time_seconds: result.processing_time_seconds,
                compression_percentage: job.file_size_input > 0 
                    ? Math.round((1 - (result.file_size_output / job.file_size_input)) * 100)
                    : 0
            });

            // Delete raw file from R2 (optional)
            if (CONFIG.DELETE_RAW_AFTER_PROCESSING) {
                try {
                    await this.r2Service.deleteObject(CONFIG.R2_RAW_BUCKET, job.r2_raw_key);
                    await this.logService.createJobLog(jobId, 'INFO', 'Raw file deleted from R2', 'CLEANUP');
                } catch (deleteError) {
                    console.warn('Failed to delete raw file:', deleteError);
                    // Non-critical error, continue
                }
            }

            return job;
        } catch (error) {
            console.error('Error completing job:', error);
            
            // Log error
            await this.logService.createJobLog(jobId, 'ERROR', `Failed to complete job: ${error.message}`, 'COMPLETE_FAIL', {
                error: error.message,
                result: result
            });

            throw error;
        }
    }

    /**
     * Fail a job
     * @param {number} jobId - Job ID
     * @param {string} workerId - Worker identifier
     * @param {string} errorMessage - Error message
     * @returns {Promise<Object>} Updated job
     */
    async failJob(jobId, workerId, errorMessage) {
        try {
            // Get current job
            const job = await this.jobRepo.getById(jobId);
            
            if (!job) {
                throw new Error(`Job ${jobId} not found`);
            }

            // Check retry count
            const retryCount = job.retry_count + 1;
            const maxRetries = CONFIG.JOB_MAX_RETRIES || 3;

            let newStatus = 'FAILED';
            if (retryCount < maxRetries) {
                // Retry: set back to PENDING
                newStatus = 'PENDING';
            }

            // Update job status
            const updatedJob = await this.jobRepo.failJob(jobId, workerId, {
                error_message: errorMessage,
                retry_count: retryCount,
                status: newStatus
            });

            // Log failure
            await this.logService.createJobLog(jobId, 'ERROR', `Job failed: ${errorMessage}`, 'FAIL', {
                worker_id: workerId,
                retry_count: retryCount,
                max_retries: maxRetries,
                new_status: newStatus
            });

            return updatedJob;
        } catch (error) {
            console.error('Error failing job:', error);
            throw error;
        }
    }

    /**
     * Get job statistics
     * @returns {Promise<Object>} Statistics
     */
    async getStatistics() {
        try {
            const stats = await this.jobRepo.getStatistics();
            
            // Calculate additional metrics
            const totalJobs = stats.total_jobs || 0;
            const completedJobs = stats.completed_jobs || 0;
            const failedJobs = stats.failed_jobs || 0;
            const pendingJobs = stats.pending_jobs || 0;
            
            return {
                summary: {
                    total_jobs: totalJobs,
                    completed: completedJobs,
                    failed: failedJobs,
                    processing: pendingJobs,
                    success_rate: totalJobs > 0 ? Math.round((completedJobs / totalJobs) * 100) : 0
                },
                recent_activity: await this.jobRepo.getRecentActivity(7),
                top_uploaders: await this.jobRepo.getTopUploaders(5),
                daily_stats: await this.jobRepo.getDailyStatistics(30)
            };
        } catch (error) {
            console.error('Error getting statistics:', error);
            throw error;
        }
    }

    /**
     * Clean up timed out jobs (should be called by cron)
     * @returns {Promise<number>} Number of cleaned up jobs
     */
    async cleanupTimedOutJobs() {
        try {
            const timeoutMinutes = CONFIG.JOB_PROCESSING_TIMEOUT_MINUTES || 60;
            const timedOutJobs = await this.jobRepo.getTimedOutJobs(timeoutMinutes);
            
            let cleanedCount = 0;
            
            for (const job of timedOutJobs) {
                try {
                    await this.failJob(
                        job.id,
                        job.worker_id || 'system',
                        `Processing timeout (${timeoutMinutes} minutes)`
                    );
                    cleanedCount++;
                } catch (error) {
                    console.error(`Failed to cleanup job ${job.id}:`, error);
                }
            }
            
            return cleanedCount;
        } catch (error) {
            console.error('Error cleaning up timed out jobs:', error);
            throw error;
        }
    }

    /**
     * Update worker heartbeat
     * @param {string} workerId - Worker identifier
     * @param {Object} heartbeatData - Heartbeat data
     * @returns {Promise<Object>} Updated heartbeat
     */
    async updateWorkerHeartbeat(workerId, heartbeatData) {
        try {
            return await this.jobRepo.updateWorkerHeartbeat(workerId, {
                status: heartbeatData.status || 'ACTIVE',
                current_job_id: heartbeatData.current_job_id,
                ip_address: heartbeatData.ip_address,
                version: heartbeatData.version || '1.0.0'
            });
        } catch (error) {
            console.error('Error updating worker heartbeat:', error);
            throw error;
        }
    }

    /**
     * Get FFmpeg preset for quality
     * @param {string} quality - 720p or 1080p
     * @returns {string} FFmpeg preset
     */
    getFfmpegPreset(quality) {
        const presets = {
            '720p': CONFIG.FFMPEG_720P_PRESET || '-c:v libx264 -preset fast -crf 23 -profile:v high -level 4.1 -movflags +faststart -c:a aac -b:a 128k -vf scale=-2:720',
            '1080p': CONFIG.FFMPEG_1080P_PRESET || '-c:v libx264 -preset fast -crf 23 -profile:v high -level 4.1 -movflags +faststart -c:a aac -b:a 128k -vf scale=-2:1080'
        };
        
        return presets[quality] || presets['720p'];
    }

    /**
     * Sanitize filename
     * @param {string} filename - Original filename
     * @returns {string} Sanitized filename
     */
    sanitizeFilename(filename) {
        // Remove extension
        const nameWithoutExt = filename.replace(/\.[^/.]+$/, '');
        
        // Convert Turkish characters to English equivalents
        const turkishMap = {
            'ç': 'c', 'Ç': 'C',
            'ğ': 'g', 'Ğ': 'G',
            'ı': 'i', 'İ': 'I',
            'ö': 'o', 'Ö': 'O',
            'ş': 's', 'Ş': 'S',
            'ü': 'u', 'Ü': 'U'
        };
        
        let sanitized = nameWithoutExt;
        for (const [turkish, english] of Object.entries(turkishMap)) {
            sanitized = sanitized.replace(new RegExp(turkish, 'g'), english);
        }
        
        // Convert to lowercase
        sanitized = sanitized.toLowerCase();
        
        // Replace spaces and special characters with hyphens
        sanitized = sanitized.replace(/[^a-z0-9]/g, '-');
        
        // Remove multiple consecutive hyphens
        sanitized = sanitized.replace(/-+/g, '-');
        
        // Remove leading/trailing hyphens
        sanitized = sanitized.replace(/^-+|-+$/g, '');
        
        // Add random suffix and .mp4 extension
        const randomSuffix = Math.random().toString(36).substring(2, 10);
        return `${sanitized}-${randomSuffix}.mp4`;
    }

    /**
     * Get jobs with filters
     * @param {Object} filters - Filter criteria
     * @returns {Promise<Array>} Filtered jobs
     */
    async getJobs(filters = {}) {
        try {
            return await this.jobRepo.getJobs(filters);
        } catch (error) {
            console.error('Error getting jobs:', error);
            throw error;
        }
    }

    /**
     * Get job by ID
     * @param {number} jobId - Job ID
     * @returns {Promise<Object>} Job details
     */
    async getJobById(jobId) {
        try {
            const job = await this.jobRepo.getById(jobId);
            if (!job) {
                throw new Error(`Job ${jobId} not found`);
            }
            
            // Get job logs
            const logs = await this.logService.getJobLogs(jobId);
            
            return {
                ...job,
                logs: logs
            };
        } catch (error) {
            console.error('Error getting job by ID:', error);
            throw error;
        }
    }
}