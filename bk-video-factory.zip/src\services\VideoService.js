/**
 * Video Service - Modernized with R2 Presigned URLs and conversion_jobs migration
 * Handles video upload, processing, and management using the new JobRepository
 */

import { JobRepository } from '../repositories/JobRepository.js';
import { VideoRepository } from '../repositories/VideoRepository.js';
import { v4 as uuidv4 } from 'uuid';

export class VideoService {
    constructor(env) {
        this.env = env;
        this.jobRepo = new JobRepository(env);
        this.videoRepo = new VideoRepository(env.DB);
        
        // Ensure proper R2 bucket names
        this.rawBucket = this.env.R2_RAW_BUCKET || 'raw-uploads';
        this.publicBucket = this.env.R2_PUBLIC_BUCKET || 'public-videos';
    }

    /**
     * Sanitize filename for R2 storage
     */
    sanitizeFilename(filename) {
        // Remove extension
        const nameWithoutExt = filename.replace(/\.[^/.]+$/, '');
        
        // Convert Turkish characters to English equivalents
        const turkishMap = {
            'ç': 'c', 'Ç': 'C',
            'ğ': 'g', 'Ğ': 'G',
            'ı': 'i', 'İ': 'I',
            'ö': 'o', 'Ö': 'O',
            'ş': 's', 'Ş': 'S',
            'ü': 'u', 'Ü': 'U'
        };
        
        let sanitized = nameWithoutExt;
        for (const [turkish, english] of Object.entries(turkishMap)) {
            sanitized = sanitized.replace(new RegExp(turkish, 'g'), english);
        }
        
        // Convert to lowercase
        sanitized = sanitized.toLowerCase();
        
        // Replace spaces and special characters with hyphens
        sanitized = sanitized.replace(/[^a-z0-9]/g, '-');
        
        // Remove multiple consecutive hyphens
        sanitized = sanitized.replace(/-+/g, '-');
        
        // Remove leading/trailing hyphens
        sanitized = sanitized.replace(/^-+|-+$/g, '');
        
        // Add random suffix and .mp4 extension
        const randomSuffix = Math.random().toString(36).substring(2, 10);
        return `${sanitized}-${randomSuffix}.mp4`;
    }

    /**
     * Generate R2 presigned URL for direct upload
     */
    async generateR2PresignedUrl(r2Key, fileSize) {
        try {
            // Cloudflare Workers R2 supports createPresignedUpload for S3-compatible presigned URLs
            // Note: This requires R2 bucket to be configured for public access or appropriate CORS
            const bucket = this.env[this.rawBucket];
            
            if (!bucket) {
                throw new Error(`R2 bucket ${this.rawBucket} not found in environment`);
            }

            // Create presigned upload URL (valid for 15 minutes)
            // Cloudflare Workers R2 API: bucket.createPresignedUpload(key, options)
            const presignedUrl = await bucket.createPresignedUpload(r2Key, {
                expiresIn: 900, // 15 minutes in seconds
                metadata: {
                    'Content-Type': 'video/mp4',
                    'x-amz-meta-file-size': fileSize.toString(),
                    'x-amz-meta-upload-method': 'direct-presigned'
                }
            });

            return presignedUrl;
        } catch (error) {
            console.error('Error generating R2 presigned URL:', error);
            
            // Fallback: Return direct upload endpoint if presigned URLs not supported
            const workerUrl = this.env.WORKER_URL || 'https://api.bilgekarga.tr';
            return `${workerUrl}/api/videos/upload/direct?key=${encodeURIComponent(r2Key)}`;
        }
    }

    /**
     * Generate presigned URL for direct R2 upload - Modernized with conversion_jobs
     */
    async generatePresignedUrl(request, userId) {
        try {
            const { fileName, fileSize, quality, tags, projectName, notes } = await request.json();
            
            // Validate file size (max 1GB)
            const maxSize = 1024 * 1024 * 1024; // 1GB
            if (fileSize > maxSize) {
                throw new Error(`File too large. Maximum size is ${maxSize / (1024 * 1024 * 1024)}GB`);
            }

            // Validate file type
            const allowedExtensions = ['mp4', 'mov', 'avi', 'mkv', 'webm'];
            const fileExt = fileName.includes('.') 
                ? fileName.substring(fileName.lastIndexOf('.') + 1).toLowerCase()
                : '';
            
            if (!allowedExtensions.includes(fileExt)) {
                throw new Error(`Invalid file type. Allowed: ${allowedExtensions.join(', ')}`);
            }

            // Validate quality
            const validQualities = ['720p', '1080p'];
            if (!validQualities.includes(quality)) {
                throw new Error(`Invalid quality. Allowed: ${validQualities.join(', ')}`);
            }

            // Generate clean filename
            const cleanName = this.sanitizeFilename(fileName);
            
            // Generate unique key for R2
            const timestamp = Date.now();
            const randomSuffix = Math.random().toString(36).substring(2, 10);
            const r2RawKey = `raw-uploads/${timestamp}-${randomSuffix}-${cleanName}`;

            // Create job in conversion_jobs table
            const jobData = {
                original_name: fileName,
                clean_name: cleanName,
                r2_raw_key: r2RawKey,
                quality: quality,
                file_size_input: fileSize,
                uploaded_by: userId,
                tags: tags || '',
                project_name: projectName || '',
                notes: notes || '',
                status: 'PENDING'
            };

            const job = await this.jobRepo.create(jobData);
            const jobId = job.id;

            // Generate real R2 presigned URL (Cloudflare Workers R2 supports presigned URLs)
            // Cloudflare Workers R2 uses the createPresignedUpload method
            const presignedUrl = await this.generateR2PresignedUrl(r2RawKey, fileSize);

            // Store upload metadata in KV for validation
            const uploadToken = uuidv4();
            await this.env.VIDEO_UPLOAD_TOKENS.put(
                `upload_token_${uploadToken}`,
                JSON.stringify({
                    jobId,
                    r2RawKey,
                    fileName,
                    cleanName,
                    fileSize,
                    quality,
                    userId,
                    expiresAt: Date.now() + 15 * 60 * 1000 // 15 minutes
                }),
                { expirationTtl: 900 } // 15 minutes
            );

            return {
                success: true,
                job_id: jobId,
                upload_url: presignedUrl,
                upload_token: uploadToken,
                r2_key: r2RawKey,
                clean_name: cleanName,
                expires_in: 900, // 15 minutes in seconds
                message: 'Presigned URL generated for direct R2 upload'
            };

        } catch (error) {
            console.error('Error generating presigned URL:', error);
            throw error;
        }
    }

    /**
     * Handle direct R2 upload completion - Modernized with conversion_jobs
     */
    async handleDirectUploadComplete(token, request) {
        try {
            // Validate token
            const tokenData = await this.env.VIDEO_UPLOAD_TOKENS.get(`upload_token_${token}`, 'json');
            if (!tokenData) {
                throw new Error('Invalid or expired upload token');
            }

            const { jobId, r2RawKey, fileName, cleanName, fileSize, quality, userId } = tokenData;

            // Verify upload completed
            const { upload_successful, actual_file_size } = await request.json();

            if (!upload_successful) {
                throw new Error('Direct upload failed');
            }

            // Get the job to verify it exists
            const job = await this.jobRepo.getById(jobId);
            if (!job) {
                throw new Error(`Job ${jobId} not found`);
            }

            // Update job with actual file size and mark as ready for processing
            // In production, this would update the job status to 'UPLOADED' or similar
            // For now, we'll just ensure the job exists and is in PENDING state
            
            // Log upload completion (KV statistics update happens in JobRepository)
            console.log(`Upload completed for job ${jobId}: ${cleanName}, size: ${actual_file_size || fileSize}`);

            // Clean up token
            await this.env.VIDEO_UPLOAD_TOKENS.delete(`upload_token_${token}`);

            return {
                success: true,
                job_id: jobId,
                clean_name: cleanName,
                status: 'uploaded',
                message: 'Direct R2 upload completed. Job is now in processing queue.',
                next_step: 'Hetner agent will automatically pick up the job for processing'
            };

        } catch (error) {
            console.error('Error handling direct upload completion:', error);
            throw error;
        }
    }

    /**
     * Handle direct upload endpoint (proxy to R2)
     */
    async handleDirectUpload(request, token) {
        // Validate token
        const tokenData = await this.env.VIDEO_UPLOAD_TOKENS.get(`upload_token_${token}`, 'json');
        if (!tokenData) {
            return new Response('Invalid or expired upload token', { status: 401 });
        }

        const { rawR2Key, videoId, fileSize } = tokenData;
        const rawBucket = this.env.R2_RAW_UPLOADS_BUCKET || 'raw-uploads';

        // Check file size limit
        const contentLength = request.headers.get('content-length');
        if (contentLength && parseInt(contentLength) > fileSize * 1.1) { // 10% tolerance
            return new Response('File size exceeds limit', { status: 413 });
        }

        try {
            // Stream the request body directly to R2
            const object = await this.env[rawBucket].put(rawR2Key, request.body, {
                httpMetadata: {
                    contentType: request.headers.get('content-type') || 'video/mp4',
                    contentDisposition: `attachment; filename="${rawR2Key.split('/').pop()}"`
                },
                customMetadata: {
                    videoId,
                    uploadMethod: 'direct',
                    originalSize: contentLength || 'unknown'
                }
            });

            return new Response(JSON.stringify({
                success: true,
                object_key: rawR2Key,
                size: object.size
            }), {
                headers: { 'Content-Type': 'application/json' }
            });

        } catch (error) {
            console.error('Direct upload to R2 failed:', error);
            return new Response(JSON.stringify({
                success: false,
                error: error.message
            }), {
                status: 500,
                headers: { 'Content-Type': 'application/json' }
            });
        }
    }

    /**
     * Add video to processing queue
     */
    async addToProcessingQueue(videoId) {
        const video = await this.videoRepo.getVideoById(videoId);
        if (!video) {
            throw new Error(`Video not found: ${videoId}`);
        }

        const queueMessage = {
            video_id: videoId,
            temp_r2_key: video.temp_r2_key,
            normalized_name: video.normalized_name,
            render_preset: video.render_preset,
            uploaded_by: video.uploaded_by,
            timestamp: new Date().toISOString()
        };

        // Send to Cloudflare Queue
        await this.env.VIDEO_PROCESSING_QUEUE.send(queueMessage);

        // Update video with queue message ID
        await this.videoRepo.updateVideoStatus(videoId, 'uploaded', {
            queue_message_id: `queue-${Date.now()}`
        });

        await this.videoRepo.addProcessingLog(videoId, {
            log_level: 'info',
            message: 'Added to processing queue',
            step: 'queue'
        });

        return true;
    }

    /**
     * Process video from queue message
     */
    async processVideoFromQueue(message) {
        const { video_id, temp_r2_key, normalized_name, render_preset, uploaded_by } = message;

        try {
            // Update status to processing
            await this.videoRepo.updateVideoStatus(video_id, 'processing');
            
            await this.videoRepo.addProcessingLog(video_id, {
                log_level: 'info',
                message: 'Starting video processing',
                step: 'processing_start'
            });

            // Get video from R2 temp bucket
            const tempBucket = this.env.VIDEO_TEMP_BUCKET;
            const tempObject = await this.env[tempBucket].get(temp_r2_key);
            
            if (!tempObject) {
                throw new Error(`Temporary video not found in R2: ${temp_r2_key}`);
            }

            // Extract metadata using FFprobe (simulated - in real implementation would call Hetner API)
            const metadata = await this.extractVideoMetadata(tempObject);
            await this.videoRepo.updateVideoMetadata(video_id, metadata);

            // Send to Hetner server for processing
            const processingResult = await this.sendToHetnerServer({
                video_id,
                temp_r2_key,
                normalized_name,
                render_preset,
                metadata
            });

            // Update with processing results
            await this.videoRepo.updateVideoStatus(video_id, 'completed', {
                perm_r2_key: processingResult.perm_r2_key,
                thumbnail_r2_key: processingResult.thumbnail_r2_key,
                hetner_job_id: processingResult.job_id,
                processing_duration: processingResult.processing_duration,
                final_file_size: processingResult.final_file_size,
                final_bitrate: processingResult.final_bitrate,
                final_resolution: processingResult.final_resolution,
                metadata_json: processingResult.metadata
            });

            await this.videoRepo.addProcessingLog(video_id, {
                log_level: 'info',
                message: 'Video processing completed successfully',
                step: 'processing_complete',
                details: {
                    processing_duration: processingResult.processing_duration,
                    final_file_size: processingResult.final_file_size,
                    final_resolution: processingResult.final_resolution
                }
            });

            return {
                success: true,
                video_id,
                status: 'completed',
                perm_url: `https://r2.bilgekarga.com/${processingResult.perm_r2_key}`,
                thumbnail_url: processingResult.thumbnail_r2_key 
                    ? `https://r2.bilgekarga.com/${processingResult.thumbnail_r2_key}`
                    : null
            };

        } catch (error) {
            console.error(`Error processing video ${video_id}:`, error);

            await this.videoRepo.updateVideoStatus(video_id, 'failed', {
                error_message: error.message
            });

            await this.videoRepo.addProcessingLog(video_id, {
                log_level: 'error',
                message: `Video processing failed: ${error.message}`,
                step: 'processing_failed',
                details: {
                    error: error.message,
                    stack: error.stack
                }
            });

            throw error;
        }
    }

    /**
     * Extract video metadata (simulated - would call FFprobe via Hetner API)
     */
    async extractVideoMetadata(videoObject) {
        // In real implementation, this would call Hetner server's FFprobe API
        // For now, return simulated metadata
        return {
            duration: 120.5, // seconds
            resolution: '1920x1080',
            bitrate: 5000, // kbps
            codec: 'h264',
            frame_rate: 30,
            audio_codec: 'aac',
            audio_channels: 2,
            audio_bitrate: 128
        };
    }

    /**
     * Send video to Hetner server for processing
     */
    async sendToHetnerServer(processingRequest) {
        const {
            video_id,
            temp_r2_key,
            normalized_name,
            render_preset,
            metadata
        } = processingRequest;

        // Hetner server API endpoint
        const hetnerApiUrl = this.env.HETNER_API_URL || 'http://hetner-server:8080/api/process';
        const apiKey = this.env.HETNER_API_KEY || '';

        // Generate output filename
        const outputName = normalizedName.replace(/\.[^/.]+$/, '') + '-processed.mp4';
        const permR2Key = `perm/${video_id}/${outputName}`;
        const thumbnailR2Key = `thumbnails/${video_id}/thumbnail.jpg`;

        // Determine Handbrake preset based on render_preset
        let handbrakePreset = '';
        if (render_preset === '720p_web') {
            handbrakePreset = '--preset="Fast 720p30" --encoder x264 --quality 22 --rate 30 --width 1280 --height 720 --optimize';
        } else if (render_preset === '1080p_web') {
            handbrakePreset = '--preset="Fast 1080p30" --encoder x264 --quality 22 --rate 30 --width 1920 --height 1080 --optimize';
        }

        // Prepare request to Hetner server
        const requestBody = {
            video_id,
            temp_r2_key,
            output_name: outputName,
            handbrake_preset: handbrakePreset,
            metadata,
            callback_url: `${this.env.WORKER_URL}/api/videos/${video_id}/callback`
        };

        // In real implementation, this would make HTTP request to Hetner server
        // For now, simulate processing
        console.log(`Sending to Hetner server: ${JSON.stringify(requestBody)}`);

        // Simulate processing delay
        await new Promise(resolve => setTimeout(resolve, 5000));

        // Return simulated result
        return {
            job_id: `hetner-${Date.now()}`,
            perm_r2_key: permR2Key,
            thumbnail_r2_key: thumbnailR2Key,
            processing_duration: 45, // seconds
            final_file_size: Math.floor(metadata.file_size * 0.7), // 70% of original
            final_bitrate: render_preset === '720p_web' ? 2500 : 5000,
            final_resolution: render_preset === '720p_web' ? '1280x720' : '1920x1080',
            metadata: {
                ...metadata,
                processed_at: new Date().toISOString(),
                handbrake_preset: handbrakePreset
            }
        };
    }

    /**
     * Handle Hetner server callback
     */
    async handleHetnerCallback(videoId, callbackData) {
        const video = await this.videoRepo.getVideoById(videoId);
        if (!video) {
            throw new Error(`Video not found: ${videoId}`);
        }

        const { status, result, error } = callbackData;

        if (status === 'completed' && result) {
            await this.videoRepo.updateVideoStatus(videoId, 'completed', {
                perm_r2_key: result.perm_r2_key,
                thumbnail_r2_key: result.thumbnail_r2_key,
                processing_duration: result.processing_duration,
                final_file_size: result.final_file_size,
                final_bitrate: result.final_bitrate,
                final_resolution: result.final_resolution,
                metadata_json: result.metadata
            });

            await this.videoRepo.addProcessingLog(videoId, {
                log_level: 'info',
                message: 'Hetner processing completed',
                step: 'hetner_callback',
                details: result
            });

            return { success: true, video_id: videoId };
        } else if (status === 'failed') {
            await this.videoRepo.updateVideoStatus(videoId, 'failed', {
                error_message: error || 'Hetner processing failed'
            });

            await this.videoRepo.addProcessingLog(videoId, {
                log_level: 'error',
                message: `Hetner processing failed: ${error}`,
                step: 'hetner_callback_failed',
                details: { error }
            });

            return { success: false, error };
        }

        return { success: false, error: 'Unknown callback status' };
    }

    /**
     * Get video details
     */
    async getVideoDetails(videoId) {
        const video = await this.videoRepo.getVideoById(videoId);
        if (!video) {
            throw new Error(`Video not found: ${videoId}`);
        }

        const logs = await this.videoRepo.getProcessingLogs(videoId, 20);

        // Generate URLs
        const tempUrl = video.temp_r2_key 
            ? `https://r2.bilgekarga.com/${video.temp_r2_key}`
            : null;
        
        const permUrl = video.perm_r2_key 
            ? `https://r2.bilgekarga.com/${video.perm_r2_key}`
            : null;
        
        const thumbnailUrl = video.thumbnail_r2_key 
            ? `https://r2.bilgekarga.com/${video.thumbnail_r2_key}`
            : null;

        return {
            ...video,
            temp_url: tempUrl,
            perm_url: permUrl,
            thumbnail_url: thumbnailUrl,
            processing_logs: logs
        };
    }

    /**
     * Search videos
     */
    async searchVideos(filters) {
        return await this.videoRepo.searchVideos(filters);
    }

    /**
     * Get video statistics
     */
    async getVideoStatistics(dateRange = '30d') {
        return await this.videoRepo.getVideoStatistics(dateRange);
    }

    /**
     * Cleanup old temporary videos
     */
    async cleanupOldVideos(days = 3) {
        const videos = await this.videoRepo.cleanupOldVideos(days);
        
        // Delete from R2
        for (const video of videos) {
            if (video.temp_r2_key) {
                const tempBucket = this.env.VIDEO_TEMP_BUCKET;
                await this.env[tempBucket].delete(video.temp_r2_key);
            }
        }

        return {
            cleaned_count: videos.length,
            videos: videos.map(v => v.id)
        };
    }

    /**
     * Update daily statistics
     */
    async updateDailyStatistics() {
        await this.videoRepo.updateDailyStatistics();
        return { success: true, message: 'Daily statistics updated' };
    }
}