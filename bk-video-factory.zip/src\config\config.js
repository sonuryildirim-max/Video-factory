/**
 * Application Configuration
 * Bilge Karga Link Hub v2.0
 */

export const CONFIG = {
    MAIN_SITE: "https://bilgekarga.com.tr",
    LOGO_URL: "https://static.ticimax.cloud/31817/uploads/editoruploads/bilgekarga-image/bilge-karga.png",
    MAX_REQUESTS_PER_MINUTE: 60,
    ALLOWED_DOMAINS: ["bilgekarga.com.tr"],
    INDEX_KEY: "sys:links_index",
    LOCK_KEY: "sys:index_lock",
    ALLOWED_ORIGINS: ["https://sales.bilgekarga.tr", "https://bilgekarga.com.tr"],
    SLUG_LENGTH: 7,
    SLUG_CHARSET: "23456789abcdefghjkmnpqrstuvwxyz",
    RESERVED_SLUGS: ["admin", "api", "health", "login", "logs", "favicon", "robots", "assets", "static", "cdn"],
    RATE_LIMITS: {
        SHORTEN_PER_HOUR: 100,
        VERIFY_PER_MINUTE: 10,
        VERIFY_GLOBAL_PER_MINUTE: 10,
        MAX_FAILED_ATTEMPTS: 6,
        BAN_DURATION_SECONDS: 3600
    },
    LOG_RETENTION_DAYS: 0, // 0 = Unlimited (manual cleanup only)
    MAX_LOGS_PER_DAY: 1000
};
