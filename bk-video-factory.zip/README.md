# Bilge Karga Link Hub v2.0

Refactored modüler yapıya sahip link kısaltma servisi.

## Yapı

```
src/
├── config/          # Konfigürasyon dosyaları
├── routes/          # Route handler'ları
├── services/        # Business logic
├── repositories/    # Data access layer
├── utils/           # Yardımcı fonksiyonlar
├── middleware/      # Middleware'ler
└── index.js         # Entry point
```

## Kurulum

1. Cloudflare Workers projesi oluşturun
2. KV Store ve D1 database bağlayın
3. Environment variables ayarlayın:
   - ADMIN_USER, ADMIN_PASS
   - ADMIN_USER_2, ADMIN_PASS_2 (root)
   - ADMIN_USER_3-5, ADMIN_PASS_3-5 (opsiyonel)

## Deploy

```bash
npm install
wrangler deploy
```

## Notlar

- HTML view'lar henüz eklenmedi (login.html, admin.html, logs.html)
- Mevcut HTML'leri `src/views/` klasörüne ekleyebilirsiniz
- Test dosyaları eklenecek

## Migration

Eski koddan yeni yapıya geçiş için:
1. Önce staging'de test edin
2. Feature flag ile aşamalı geçiş yapın
3. Monitoring ekleyin
