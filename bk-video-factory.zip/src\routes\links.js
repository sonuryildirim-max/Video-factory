/**
 * Link Routes
 */

import { LinkService } from '../services/LinkService.js';
import { LogService } from '../services/LogService.js';
import { CacheService } from '../services/CacheService.js';
import { KVRepository } from '../repositories/KVRepository.js';
import { D1Repository } from '../repositories/D1Repository.js';
import { requireAuth, requireRoot } from '../middleware/auth.js';
import { checkRateLimit } from '../middleware/rateLimit.js';
import { CONFIG } from '../config/config.js';
import { handleError } from '../utils/errors.js';
import { SECURITY_HEADERS } from '../config/constants.js';
import { isSocialBot } from '../utils/userAgent.js';

/**
 * Handle link routes
 */
export async function handleLinkRoutes(request, env, ctx) {
    const url = new URL(request.url);
    const ip = request.headers.get('CF-Connecting-IP') || 'unknown';
    const userAgent = request.headers.get('User-Agent') || 'unknown';
    const kvRepo = new KVRepository(env.LINKS);
    const d1Repo = new D1Repository(env.DB);
    const linkService = new LinkService(kvRepo, d1Repo);
    const logService = new LogService(kvRepo, d1Repo);
    const cacheService = new CacheService(kvRepo);

    try {
        // POST /api/shorten
        if (request.method === 'POST' && url.pathname.includes('/shorten')) {
            const authResult = await requireAuth(request, env);
            if (!authResult.valid) {
                return Response.json({ error: 'Yetkisiz erisim' }, { status: 401 });
            }

            // Rate limit check
            const shortenAllowed = await checkRateLimit(
                env,
                `shorten:${ip}`,
                CONFIG.RATE_LIMITS.SHORTEN_PER_HOUR,
                3600
            );
            if (!shortenAllowed) {
                return Response.json(
                    { error: 'Saatlik link olusturma limitine ulastiniz.' },
                    {
                        status: 429,
                        headers: { 'Retry-After': '3600' }
                    }
                );
            }

            const body = await request.json();
            const hostname = url.hostname;
            const result = await linkService.shortenLink(
                { ...body, hostname },
                authResult,
                ctx
            );

            // Log action
            const logAction = result.overwritten ? 'LINK_OVERWRITTEN' :
                (result.cached ? 'LINK_CACHED' : 'LINK_CREATED');
            ctx.waitUntil(
                logService.writeAuditLog(logAction, {
                    user: authResult.user,
                    ip,
                    slug: result.slug,
                    targetUrl: body.url,
                    campaign: body.campaign || null,
                    source: body.source || null
                }, request)
            );

            return Response.json({ success: true, ...result });
        }

        // GET /api/stats?slug=xxx
        if (request.method === 'GET' && url.pathname.includes('/stats')) {
            const authResult = await requireAuth(request, env);
            if (!authResult.valid) {
                return Response.json({ error: 'Yetkisiz erisim' }, { status: 401 });
            }

            const slug = url.searchParams.get('slug');
            if (!slug) {
                return Response.json({ error: 'slug parametresi gerekli' }, { status: 400 });
            }

            const link = await linkService.getLink(slug);
            return Response.json({
                slug,
                url: link.url,
                clicks: link.clicks || 0,
                created: link.created,
                createdBy: link.createdBy,
                updatedAt: link.updatedAt
            });
        }

        // GET /api/links
        if (request.method === 'GET' && url.pathname.includes('/links')) {
            const authResult = await requireRoot(request, env);

            const filters = {
                search: url.searchParams.get('search') || '',
                startDate: url.searchParams.get('startDate'),
                endDate: url.searchParams.get('endDate'),
                sort: url.searchParams.get('sort') || 'clicks-desc',
                page: parseInt(url.searchParams.get('page')) || 1,
                limit: Math.min(parseInt(url.searchParams.get('limit')) || 50, 200)
            };

            const result = await d1Repo.getLinks(filters);
            return Response.json({
                count: result.totalCount,
                page: result.page,
                totalPages: result.totalPages,
                limit: result.limit,
                hasMore: result.page < result.totalPages,
                links: result.links
            });
        }

        return Response.json({ error: 'Not found' }, { status: 404 });
    } catch (error) {
        return handleError(error, request);
    }
}

/**
 * Handle link redirect
 */
export async function handleLinkRedirect(request, env, ctx, slug) {
    const ip = request.headers.get('CF-Connecting-IP') || 'unknown';
    const userAgent = request.headers.get('User-Agent') || 'unknown';
    const kvRepo = new KVRepository(env.LINKS);
    const d1Repo = new D1Repository(env.DB);
    const linkService = new LinkService(kvRepo, d1Repo);
    const logService = new LogService(kvRepo, d1Repo);
    const cacheService = new CacheService(kvRepo);

    try {
        const link = await linkService.incrementClicks(slug, ctx);

        // Log click
        ctx.waitUntil(
            logService.writeAuditLog('LINK_CLICKED', {
                slug,
                ip,
                userAgent,
                targetUrl: link.url,
                source: link.source || null,
                campaign: link.campaign || null
            }, request)
        );

        // Handle social media bots
        if (isSocialBot(userAgent)) {
            const og = await cacheService.fetchOgTags(slug, link.url);
            if (og && (og.title || og.image)) {
                const ogHtml = cacheService.buildOgHtml(og, link.url, slug);
                return new Response(ogHtml, {
                    headers: { ...SECURITY_HEADERS, 'Content-Type': 'text/html;charset=utf-8' }
                });
            }
        }

        return Response.redirect(link.url, 302);
    } catch (error) {
        if (error.code === 'NOT_FOUND') {
            // Return 404 page
            return new Response('404 - Link Bulunamadi', {
                status: 404,
                headers: { ...SECURITY_HEADERS, 'Content-Type': 'text/html;charset=utf-8' }
            });
        }
        return handleError(error, request);
    }
}
