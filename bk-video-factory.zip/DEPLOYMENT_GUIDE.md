# 🚀 Deployment Guide

## Refactoring Tamamlandı!

Tüm kodlar modüler yapıya dönüştürüldü. İşte yapılması gerekenler:

## ✅ Tamamlananlar

- ✅ Config dosyaları ayrıldı
- ✅ Utils modülleri oluşturuldu
- ✅ Repository katmanı hazır
- ✅ Service katmanı hazır
- ✅ Route handler'ları hazır
- ✅ Middleware'ler hazır
- ✅ Ana entry point hazır

## ⚠️ Eksikler (Manuel Eklenmesi Gerekenler)

### 1. HTML View'lar
Mevcut HTML'leri `src/views/` klasörüne ekleyin:
- `login.html` - Login sayfası
- `admin.html` - Admin paneli
- `logs.html` - Logs sayfası
- `404.html` - 404 sayfası

**Not:** Mevcut kodunuzdaki HTML string'lerini bu dosyalara kopyalayın.

### 2. View Renderer
`src/utils/viewRenderer.js` dosyası oluşturun ve HTML'leri yükleyin:

```javascript
import { CONFIG } from '../config/config.js';

export function renderView(templateName, data = {}) {
    // HTML dosyalarını oku ve placeholder'ları değiştir
    // Örnek: fs.readFileSync veya fetch ile yükle
}
```

### 3. wrangler.toml
Cloudflare Workers config dosyası:

```toml
name = "bilge-karga-link-hub"
main = "src/index.js"
compatibility_date = "2024-01-01"

[env.production]
vars = { ENVIRONMENT = "production" }

[[kv_namespaces]]
binding = "LINKS"
id = "your-kv-namespace-id"

[[d1_databases]]
binding = "DB"
database_name = "bilge-karga-db"
database_id = "your-d1-database-id"
```

## 📋 Deployment Adımları

### 1. Cloudflare Workers Setup
```bash
# Wrangler CLI kurulumu
npm install -g wrangler

# Login
wrangler login

# KV Namespace oluştur
wrangler kv:namespace create LINKS
wrangler kv:namespace create LINKS --preview

# D1 Database oluştur
wrangler d1 create bilge-karga-db
```

### 2. D1 Schema
D1 database'de şu tabloları oluşturun:

```sql
CREATE TABLE IF NOT EXISTS links (
    slug TEXT PRIMARY KEY,
    url TEXT NOT NULL,
    clicks INTEGER DEFAULT 0,
    created TEXT NOT NULL,
    created_by TEXT,
    updated_at TEXT,
    source TEXT,
    campaign TEXT
);

CREATE TABLE IF NOT EXISTS logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    action TEXT NOT NULL,
    details TEXT,
    ip TEXT,
    ua TEXT,
    country TEXT,
    city TEXT,
    timestamp TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_logs_timestamp ON logs(timestamp);
CREATE INDEX IF NOT EXISTS idx_logs_action ON logs(action);
```

### 3. Environment Variables
Cloudflare Dashboard'dan şu değişkenleri ekleyin:
- `ADMIN_USER`
- `ADMIN_PASS`
- `ADMIN_USER_2` (root)
- `ADMIN_PASS_2` (root)
- `ADMIN_USER_3-5` (opsiyonel)
- `ADMIN_PASS_3-5` (opsiyonel)

### 4. Deploy
```bash
cd bilge-karga-refactored
npm install
wrangler deploy
```

## 🔄 Migration Stratejisi

### Aşama 1: Test
1. Staging environment'da test edin
2. Tüm endpoint'leri kontrol edin
3. Veri tutarlılığını doğrulayın

### Aşama 2: Aşamalı Geçiş
1. Feature flag ile yeni/eski kod arasında geçiş
2. Önce kritik olmayan endpoint'ler
3. Sonra kritik endpoint'ler

### Aşama 3: Monitoring
1. Error rate'i takip edin
2. Response time'ları izleyin
3. KV ve D1 kullanımını kontrol edin

## 🐛 Sorun Giderme

### KV Store erişim hatası
- `wrangler.toml`'da binding'i kontrol edin
- Namespace ID'lerini doğrulayın

### D1 query hatası
- Database ID'yi kontrol edin
- Schema'yı doğrulayın
- Migration'ları çalıştırın

### Auth hatası
- Environment variables'ı kontrol edin
- Basic Auth header formatını doğrulayın

## 📞 Destek

Sorun yaşarsanız:
1. Console log'ları kontrol edin
2. Cloudflare Dashboard'dan error'ları inceleyin
3. Test endpoint'lerini kullanın: `/health`

## ✨ Sonraki Adımlar

1. HTML view'ları ekleyin
2. Unit testler yazın
3. Integration testler ekleyin
4. Performance monitoring ekleyin
5. Documentation tamamlayın

---

**Hazırlayan:** AI Assistant  
**Tarih:** 2026-02-16  
**Versiyon:** 2.0.0
