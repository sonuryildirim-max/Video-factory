/**
 * Admin Routes
 */

import { KVRepository } from '../repositories/KVRepository.js';
import { requireRoot } from '../middleware/auth.js';
import { handleError } from '../utils/errors.js';
import { SECURITY_HEADERS } from '../config/constants.js';
import { CONFIG } from '../config/config.js';

/**
 * Handle admin routes
 */
export async function handleAdminRoutes(request, env, ctx) {
    const url = new URL(request.url);
    const kvRepo = new KVRepository(env.LINKS);

    try {
        // GET /admin (HTML page)
        if (url.pathname === '/admin') {
            // Return admin HTML page (will be loaded from views later)
            return new Response('Admin page - HTML to be added', {
                headers: { ...SECURITY_HEADERS, 'Content-Type': 'text/html;charset=utf-8' }
            });
        }

        // POST /api/admin/reindex
        if (request.method === 'POST' && url.pathname.includes('/admin/reindex')) {
            await requireRoot(request, env);

            // Scan all keys
            let listResult = await env.LINKS.list();
            let keys = listResult.keys;
            while (!listResult.list_complete) {
                listResult = await env.LINKS.list({ cursor: listResult.cursor });
                keys = keys.concat(listResult.keys);
            }

            // Filter out system keys
            const prefixes = ['rate:', 'ban:', 'fail:', 'log:', 'cache:', 'og:', 'sys:'];
            const slugs = keys
                .filter(k => !prefixes.some(p => k.name.startsWith(p)))
                .map(k => k.name);

            // Atomic write to index
            if (!await kvRepo.acquireLock()) {
                return Response.json({ error: 'Sistem mesgul, tekrar deneyin' }, { status: 503 });
            }
            try {
                await kvRepo.saveIndex(slugs);
            } finally {
                await kvRepo.releaseLock();
            }

            return new Response(`Index rebuilt: ${slugs.length} links indexed.`, {
                status: 200,
                headers: SECURITY_HEADERS
            });
        }

        // POST /api/admin/cleanup
        if (request.method === 'POST' && url.pathname.includes('/admin/cleanup')) {
            await requireRoot(request, env);

            const days = parseInt(url.searchParams.get('days')) || 180;
            if (days < 1 || days > 3650) {
                return Response.json({ error: 'Invalid days parameter' }, { status: 400 });
            }

            await env.DB.prepare("DELETE FROM logs WHERE timestamp < datetime('now', '-' || ? || ' days')")
                .bind(days).run();

            return Response.json({ success: true, message: `${days} günden eski veriler temizlendi` });
        }

        return Response.json({ error: 'Not found' }, { status: 404 });
    } catch (error) {
        return handleError(error, request);
    }
}
