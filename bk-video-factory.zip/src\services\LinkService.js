/**
 * Link Service
 * Business logic for link operations
 */

import { ValidationError, NotFoundError } from '../utils/errors.js';
import { validateTargetUrl, validateSlug, generateSlug, hashUrl } from '../utils/validation.js';
import { cleanTrackingParams, addUtmParams } from '../utils/url.js';
import { CONFIG } from '../config/config.js';

export class LinkService {
    constructor(kvRepo, d1Repo) {
        this.kvRepo = kvRepo;
        this.d1Repo = d1Repo;
    }

    /**
     * Shorten a URL
     */
    async shortenLink(data, authUser, ctx) {
        const { url, customSlug, campaign, source, forceOverwrite, hostname } = data;

        // Validate URL
        const validation = validateTargetUrl(url);
        if (!validation.ok) {
            throw new ValidationError(validation.error);
        }

        // Clean and add UTM params
        const cleanedUrl = cleanTrackingParams(validation.url);
        const finalUrl = addUtmParams(cleanedUrl, campaign, source);

        let slug, isCached = false, isOverwritten = false;
        let previousUrl = null;

        // Handle custom slug or generate new one
        if (customSlug && customSlug.trim().length > 0) {
            const slugResult = await this.handleCustomSlug(customSlug, finalUrl, forceOverwrite, authUser);
            slug = slugResult.slug;
            isOverwritten = slugResult.overwritten || false;
            previousUrl = slugResult.previousUrl || null;
        } else {
            const result = await this.handleAutoSlug(finalUrl);
            slug = result.slug;
            isCached = result.cached;
        }

        // Save link if not cached
        if (!isCached) {
            const linkData = {
                url: finalUrl,
                created: new Date().toISOString(),
                clicks: 0,
                createdBy: authUser.user,
                updatedAt: isOverwritten ? new Date().toISOString() : null,
                source: source || null,
                campaign: campaign || null
            };

            await this.kvRepo.saveLink(slug, linkData);
            await this.kvRepo.addToIndex(slug);

            // Shadow copy to D1 (async)
            ctx.waitUntil(
                this.d1Repo.createLink({ slug, ...linkData })
                    .catch(e => console.error('D1 link shadow write error:', e))
            );
        }

        return {
            slug,
            shortUrl: `https://${hostname}/${slug}`,
            cached: isCached,
            overwritten: isOverwritten
        };
    }

    /**
     * Handle custom slug creation
     */
    async handleCustomSlug(customSlug, finalUrl, forceOverwrite, authUser) {
        const slug = customSlug.trim().toLowerCase();

        // Validate slug format
        const slugValidation = validateSlug(slug);
        if (!slugValidation.ok) {
            throw new ValidationError(slugValidation.error);
        }

        const existing = await this.kvRepo.getLink(slug);
        if (existing) {
            if (forceOverwrite && authUser.isRoot) {
                const oldHash = await hashUrl(existing.url);
                await this.kvRepo.deleteCachedSlug(oldHash);
                return { slug, overwritten: true, previousUrl: existing.url };
            }
            throw new ValidationError("Bu isim zaten kullaniliyor!", {
                existingUrl: existing.url,
                slug
            });
        }

        return { slug, overwritten: false };
    }

    /**
     * Handle auto slug generation
     */
    async handleAutoSlug(finalUrl) {
        const urlHash = await hashUrl(finalUrl);
        const cachedSlug = await this.kvRepo.getCachedSlug(urlHash);

        if (cachedSlug) {
            const existingRecord = await this.kvRepo.getLink(cachedSlug);
            if (existingRecord) {
                return { slug: cachedSlug, cached: true };
            } else {
                await this.kvRepo.deleteCachedSlug(urlHash);
            }
        }

        const slug = generateSlug();
        await this.kvRepo.cacheSlug(urlHash, slug);
        return { slug, cached: false };
    }

    /**
     * Get link by slug
     */
    async getLink(slug) {
        const link = await this.kvRepo.getLink(slug);
        if (!link || !link.url) {
            throw new NotFoundError("Link bulunamadi");
        }
        return link;
    }

    /**
     * Increment click count
     */
    async incrementClicks(slug, ctx) {
        const link = await this.kvRepo.getLink(slug);
        if (!link) return;

        link.clicks = (link.clicks || 0) + 1;
        await this.kvRepo.saveLink(slug, link);

        // Shadow update in D1
        ctx.waitUntil(
            this.d1Repo.updateLinkClicks(slug)
                .catch(e => console.error('D1 click update error:', e))
        );

        return link;
    }
}
