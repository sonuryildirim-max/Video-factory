/**
 * Authentication Service
 */

import { timingSafeEqual } from '../utils/security.js';

export class AuthService {
    constructor(env) {
        this.env = env;
    }

    /**
     * Verify Basic Auth credentials
     */
    verifyBasicAuth(request) {
        const header = request.headers.get("Authorization");
        if (!header || !header.startsWith("Basic ")) {
            return { valid: false, user: null, isRoot: false };
        }

        try {
            const decoded = atob(header.slice(6));
            const colonIdx = decoded.indexOf(":");
            if (colonIdx === -1) {
                return { valid: false, user: null, isRoot: false };
            }

            const user = decoded.slice(0, colonIdx);
            const pass = decoded.slice(colonIdx + 1);

            // Check ADMIN_USER (normal admin)
            if (this.env.ADMIN_USER && this.env.ADMIN_PASS) {
                if (timingSafeEqual(user, this.env.ADMIN_USER) &&
                    timingSafeEqual(pass, this.env.ADMIN_PASS)) {
                    return { valid: true, user, isRoot: false };
                }
            }

            // Check ADMIN_USER_2 (root admin)
            if (this.env.ADMIN_USER_2 && this.env.ADMIN_PASS_2) {
                if (timingSafeEqual(user, this.env.ADMIN_USER_2) &&
                    timingSafeEqual(pass, this.env.ADMIN_PASS_2)) {
                    return { valid: true, user, isRoot: true };
                }
            }

            // Check other admin users (ADMIN_USER_3, 4, 5)
            for (let i = 3; i <= 5; i++) {
                const adminUser = this.env[`ADMIN_USER_${i}`];
                const adminPass = this.env[`ADMIN_PASS_${i}`];
                if (adminUser && adminPass) {
                    if (timingSafeEqual(user, adminUser) &&
                        timingSafeEqual(pass, adminPass)) {
                        return { valid: true, user, isRoot: false };
                    }
                }
            }

            return { valid: false, user: null, isRoot: false };
        } catch (e) {
            return { valid: false, user: null, isRoot: false };
        }
    }
}
