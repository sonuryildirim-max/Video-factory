/**
 * Analytics Service
 * Handles analytics data aggregation
 */

export class AnalyticsService {
    constructor(d1Repo) {
        this.d1Repo = d1Repo;
    }

    /**
     * Get analytics data
     */
    async getAnalyticsData() {
        const today = new Date().toISOString().slice(0, 10);
        const weekAgo = new Date(Date.now() - 7 * 86400000).toISOString().slice(0, 10);
        const monthAgo = new Date(Date.now() - 30 * 86400000).toISOString().slice(0, 10);
        const dayAgo = new Date(Date.now() - 86400000).toISOString().slice(0, 10);

        return await this.d1Repo.getAnalyticsData({
            today,
            weekAgo,
            monthAgo,
            dayAgo
        });
    }
}
