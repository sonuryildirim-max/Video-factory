/**
 * Authentication Middleware
 */

import { AuthService } from '../services/AuthService.js';
import { AuthError } from '../utils/errors.js';

/**
 * Require authentication
 */
export async function requireAuth(request, env) {
    const authService = new AuthService(env);
    const authResult = authService.verifyBasicAuth(request);

    if (!authResult.valid) {
        throw new AuthError('Yetkisiz erisim');
    }

    return authResult;
}

/**
 * Require root/admin privileges
 */
export async function requireRoot(request, env) {
    const authResult = await requireAuth(request, env);

    if (!authResult.isRoot) {
        throw new AuthError('Bu islem icin root yetkisi gerekli', 403);
    }

    return authResult;
}
