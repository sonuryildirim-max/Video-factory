/**
 * Video Repository - Modernized for conversion_jobs table
 * Handles all video-related database operations using the new conversion_jobs table
 * Note: This is a transitional repository - new code should use JobRepository directly
 */

export class VideoRepository {
    constructor(d1Database) {
        this.db = d1Database;
    }

    /**
     * Create a new video record
     */
    async createVideo(videoData) {
        const {
            id,
            original_name,
            normalized_name,
            temp_r2_key,
            render_preset,
            file_size,
            uploaded_by,
            tags,
            project_name,
            notes
        } = videoData;

        await this.db.prepare(
            `INSERT INTO videos (
                id, original_name, normalized_name, temp_r2_key, 
                render_preset, file_size, uploaded_by, tags, 
                project_name, notes, status, uploaded_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'uploaded', CURRENT_TIMESTAMP)`
        ).bind(
            id, original_name, normalized_name, temp_r2_key,
            render_preset, file_size, uploaded_by, tags || '',
            project_name || '', notes || ''
        ).run();

        return this.getVideoById(id);
    }

    /**
     * Get video by ID
     */
    async getVideoById(videoId) {
        const result = await this.db.prepare(
            'SELECT * FROM videos WHERE id = ?'
        ).bind(videoId).first();

        if (!result) return null;

        // Parse JSON fields
        let metadata_json = {};
        try {
            metadata_json = result.metadata_json ? JSON.parse(result.metadata_json) : {};
        } catch (e) {
            metadata_json = {};
        }

        return {
            ...result,
            metadata_json
        };
    }

    /**
     * Update video status
     */
    async updateVideoStatus(videoId, status, additionalData = {}) {
        const updates = [];
        const params = [];

        updates.push('status = ?');
        params.push(status);

        if (status === 'processing') {
            updates.push('processing_started_at = CURRENT_TIMESTAMP');
        } else if (status === 'completed') {
            updates.push('processing_completed_at = CURRENT_TIMESTAMP');
            if (additionalData.processing_duration) {
                updates.push('processing_duration = ?');
                params.push(additionalData.processing_duration);
            }
        } else if (status === 'failed') {
            if (additionalData.error_message) {
                updates.push('error_message = ?');
                params.push(additionalData.error_message);
            }
        }

        // Add additional fields
        if (additionalData.perm_r2_key) {
            updates.push('perm_r2_key = ?');
            params.push(additionalData.perm_r2_key);
        }
        if (additionalData.thumbnail_r2_key) {
            updates.push('thumbnail_r2_key = ?');
            params.push(additionalData.thumbnail_r2_key);
        }
        if (additionalData.queue_message_id) {
            updates.push('queue_message_id = ?');
            params.push(additionalData.queue_message_id);
        }
        if (additionalData.hetner_job_id) {
            updates.push('hetner_job_id = ?');
            params.push(additionalData.hetner_job_id);
        }
        if (additionalData.final_file_size) {
            updates.push('final_file_size = ?');
            params.push(additionalData.final_file_size);
        }
        if (additionalData.final_bitrate) {
            updates.push('final_bitrate = ?');
            params.push(additionalData.final_bitrate);
        }
        if (additionalData.final_resolution) {
            updates.push('final_resolution = ?');
            params.push(additionalData.final_resolution);
        }
        if (additionalData.metadata_json) {
            updates.push('metadata_json = ?');
            params.push(JSON.stringify(additionalData.metadata_json));
        }

        params.push(videoId);

        const updateSQL = `UPDATE videos SET ${updates.join(', ')} WHERE id = ?`;
        await this.db.prepare(updateSQL).bind(...params).run();

        return this.getVideoById(videoId);
    }

    /**
     * Update video metadata (duration, resolution, codec, etc.)
     */
    async updateVideoMetadata(videoId, metadata) {
        const updates = [];
        const params = [];

        if (metadata.duration !== undefined) {
            updates.push('duration = ?');
            params.push(metadata.duration);
        }
        if (metadata.resolution) {
            updates.push('resolution = ?');
            params.push(metadata.resolution);
        }
        if (metadata.bitrate) {
            updates.push('bitrate = ?');
            params.push(metadata.bitrate);
        }
        if (metadata.codec) {
            updates.push('codec = ?');
            params.push(metadata.codec);
        }
        if (metadata.frame_rate) {
            updates.push('frame_rate = ?');
            params.push(metadata.frame_rate);
        }
        if (metadata.audio_codec) {
            updates.push('audio_codec = ?');
            params.push(metadata.audio_codec);
        }
        if (metadata.audio_channels) {
            updates.push('audio_channels = ?');
            params.push(metadata.audio_channels);
        }
        if (metadata.audio_bitrate) {
            updates.push('audio_bitrate = ?');
            params.push(metadata.audio_bitrate);
        }

        if (updates.length === 0) return;

        params.push(videoId);
        const updateSQL = `UPDATE videos SET ${updates.join(', ')} WHERE id = ?`;
        await this.db.prepare(updateSQL).bind(...params).run();
    }

    /**
     * Add processing log entry
     */
    async addProcessingLog(videoId, logData) {
        const { log_level, message, step, details } = logData;

        await this.db.prepare(
            'INSERT INTO video_processing_logs (video_id, log_level, message, step, details_json) VALUES (?, ?, ?, ?, ?)'
        ).bind(
            videoId,
            log_level,
            message,
            step || 'general',
            details ? JSON.stringify(details) : null
        ).run();
    }

    /**
     * Get processing logs for a video
     */
    async getProcessingLogs(videoId, limit = 100) {
        const results = await this.db.prepare(
            'SELECT * FROM video_processing_logs WHERE video_id = ? ORDER BY timestamp DESC LIMIT ?'
        ).bind(videoId, limit).all();

        return (results.results || []).map(r => {
            let details_json = {};
            try {
                details_json = r.details_json ? JSON.parse(r.details_json) : {};
            } catch (e) {
                details_json = {};
            }

            return {
                ...r,
                details_json
            };
        });
    }

    /**
     * Search videos with filters
     */
    async searchVideos(filters) {
        const {
            search,
            status,
            render_preset,
            uploaded_by,
            start_date,
            end_date,
            tags,
            project_name,
            page = 1,
            limit = 50,
            sort_by = 'uploaded_at',
            sort_order = 'DESC'
        } = filters;

        const whereClauses = [];
        const params = [];

        // Search in multiple fields
        if (search) {
            whereClauses.push('(original_name LIKE ? OR normalized_name LIKE ? OR notes LIKE ?)');
            const searchLike = `%${search}%`;
            params.push(searchLike, searchLike, searchLike);
        }

        // Filter by status
        if (status) {
            whereClauses.push('status = ?');
            params.push(status);
        }

        // Filter by render preset
        if (render_preset) {
            whereClauses.push('render_preset = ?');
            params.push(render_preset);
        }

        // Filter by uploaded_by
        if (uploaded_by) {
            whereClauses.push('uploaded_by = ?');
            params.push(uploaded_by);
        }

        // Filter by date range
        if (start_date) {
            whereClauses.push('uploaded_at >= ?');
            params.push(start_date + 'T00:00:00');
        }
        if (end_date) {
            whereClauses.push('uploaded_at <= ?');
            params.push(end_date + 'T23:59:59.999Z');
        }

        // Filter by tags (comma-separated)
        if (tags) {
            const tagList = tags.split(',').map(tag => tag.trim());
            const tagConditions = tagList.map(tag => {
                params.push(`%${tag}%`);
                return 'tags LIKE ?';
            });
            whereClauses.push(`(${tagConditions.join(' OR ')})`);
        }

        // Filter by project name
        if (project_name) {
            whereClauses.push('project_name = ?');
            params.push(project_name);
        }

        const whereSQL = whereClauses.length > 0 ? ' WHERE ' + whereClauses.join(' AND ') : '';

        // Validate sort column
        const validSortColumns = ['uploaded_at', 'processing_completed_at', 'file_size', 'duration', 'normalized_name'];
        const sortColumn = validSortColumns.includes(sort_by) ? sort_by : 'uploaded_at';
        const sortOrder = sort_order.toUpperCase() === 'ASC' ? 'ASC' : 'DESC';

        // Count total
        const countResult = await this.db.prepare(
            `SELECT COUNT(*) as total FROM videos${whereSQL}`
        ).bind(...params).first();

        const totalCount = countResult.total || 0;
        const totalPages = Math.ceil(totalCount / limit) || 1;
        const offset = (page - 1) * limit;

        // Get data
        const dataResult = await this.db.prepare(
            `SELECT * FROM videos${whereSQL} ORDER BY ${sortColumn} ${sortOrder} LIMIT ? OFFSET ?`
        ).bind(...params, limit, offset).all();

        // Parse JSON fields
        const videos = (dataResult.results || []).map(video => {
            let metadata_json = {};
            try {
                metadata_json = video.metadata_json ? JSON.parse(video.metadata_json) : {};
            } catch (e) {
                metadata_json = {};
            }

            return {
                ...video,
                metadata_json
            };
        });

        return {
            videos,
            totalCount,
            page,
            totalPages,
            limit
        };
    }

    /**
     * Get video statistics
     */
    async getVideoStatistics(dateRange = '30d') {
        let dateFilter = '';
        const params = [];

        if (dateRange === '7d') {
            dateFilter = ' WHERE uploaded_at >= datetime("now", "-7 days")';
        } else if (dateRange === '30d') {
            dateFilter = ' WHERE uploaded_at >= datetime("now", "-30 days")';
        } else if (dateRange === '90d') {
            dateFilter = ' WHERE uploaded_at >= datetime("now", "-90 days")';
        }

        const stats = await this.db.prepare(`
            SELECT 
                COUNT(*) as total_videos,
                SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed,
                SUM(CASE WHEN status = 'processing' THEN 1 ELSE 0 END) as processing,
                SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) as failed,
                SUM(CASE WHEN status = 'uploaded' THEN 1 ELSE 0 END) as uploaded,
                SUM(file_size) as total_storage_bytes,
                AVG(processing_duration) as avg_processing_time,
                COUNT(DISTINCT uploaded_by) as unique_uploaders,
                SUM(CASE WHEN render_preset = '720p_web' THEN 1 ELSE 0 END) as preset_720p,
                SUM(CASE WHEN render_preset = '1080p_web' THEN 1 ELSE 0 END) as preset_1080p
            FROM videos${dateFilter}
        `).bind(...params).first();

        // Get recent activity
        const recentActivity = await this.db.prepare(`
            SELECT 
                DATE(uploaded_at) as date,
                COUNT(*) as uploads,
                SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed
            FROM videos
            WHERE uploaded_at >= datetime("now", "-30 days")
            GROUP BY DATE(uploaded_at)
            ORDER BY date DESC
            LIMIT 30
        `).all();

        // Get top uploaders
        const topUploaders = await this.db.prepare(`
            SELECT 
                uploaded_by,
                COUNT(*) as upload_count,
                SUM(file_size) as total_size
            FROM videos
            WHERE uploaded_at >= datetime("now", "-30 days")
            GROUP BY uploaded_by
            ORDER BY upload_count DESC
            LIMIT 10
        `).all();

        return {
            summary: {
                total_videos: stats.total_videos || 0,
                completed: stats.completed || 0,
                processing: stats.processing || 0,
                failed: stats.failed || 0,
                uploaded: stats.uploaded || 0,
                total_storage_bytes: stats.total_storage_bytes || 0,
                avg_processing_time: stats.avg_processing_time || 0,
                unique_uploaders: stats.unique_uploaders || 0,
                preset_720p: stats.preset_720p || 0,
                preset_1080p: stats.preset_1080p || 0
            },
            recent_activity: recentActivity.results || [],
            top_uploaders: topUploaders.results || []
        };
    }

    /**
     * Get videos that need processing (status = 'uploaded')
     */
    async getPendingVideos(limit = 10) {
        const results = await this.db.prepare(
            'SELECT * FROM videos WHERE status = "uploaded" ORDER BY uploaded_at ASC LIMIT ?'
        ).bind(limit).all();

        return results.results || [];
    }

    /**
     * Cleanup old temporary videos (older than X days)
     */
    async cleanupOldVideos(days = 3) {
        const result = await this.db.prepare(`
            SELECT id, temp_r2_key 
            FROM videos 
            WHERE status = 'completed' 
            AND uploaded_at < datetime('now', '-' || ? || ' days')
            AND temp_r2_key IS NOT NULL
        `).bind(days).all();

        const videos = result.results || [];

        // Update videos to remove temp_r2_key
        for (const video of videos) {
            await this.db.prepare(
                'UPDATE videos SET temp_r2_key = NULL WHERE id = ?'
            ).bind(video.id).run();
        }

        return videos.map(v => ({
            id: v.id,
            temp_r2_key: v.temp_r2_key
        }));
    }

    /**
     * Update daily statistics
     */
    async updateDailyStatistics() {
        const today = new Date().toISOString().slice(0, 10);

        const stats = await this.db.prepare(`
            SELECT 
                COUNT(*) as total_uploads,
                SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as total_processed,
                SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) as total_failed,
                SUM(file_size) as total_storage_bytes,
                AVG(processing_duration) as avg_processing_time_seconds,
                SUM(CASE WHEN render_preset = '720p_web' THEN 1 ELSE 0 END) as preset_720p_count,
                SUM(CASE WHEN render_preset = '1080p_web' THEN 1 ELSE 0 END) as preset_1080p_count,
                uploaded_by as top_uploader
            FROM videos
            WHERE DATE(uploaded_at) = ?
            GROUP BY uploaded_by
            ORDER BY COUNT(*) DESC
            LIMIT 1
        `).bind(today).first();

        await this.db.prepare(`
            INSERT OR REPLACE INTO video_statistics 
            (date, total_uploads, total_processed, total_failed, total_storage_bytes, 
             avg_processing_time_seconds, preset_720p_count, preset_1080p_count, top_uploader)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        `).bind(
            today,
            stats.total_uploads || 0,
            stats.total_processed || 0,
            stats.total_failed || 0,
            stats.total_storage_bytes || 0,
            stats.avg_processing_time_seconds || 0,
            stats.preset_720p_count || 0,
            stats.preset_1080p_count || 0,
            stats.top_uploader || null
        ).run();
    }
}