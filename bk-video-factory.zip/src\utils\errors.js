/**
 * Custom Error Classes
 */

export class AppError extends Error {
    constructor(message, statusCode = 500, code = 'INTERNAL_ERROR') {
        super(message);
        this.statusCode = statusCode;
        this.code = code;
        this.name = 'AppError';
    }
}

export class ValidationError extends AppError {
    constructor(message, details = null) {
        super(message, 400, 'VALIDATION_ERROR');
        this.details = details;
    }
}

export class AuthError extends AppError {
    constructor(message, statusCode = 401) {
        super(message, statusCode, 'AUTH_ERROR');
    }
}

export class NotFoundError extends AppError {
    constructor(message = 'Resource not found') {
        super(message, 404, 'NOT_FOUND');
    }
}

export class RateLimitError extends AppError {
    constructor(message = 'Rate limit exceeded', retryAfter = 60) {
        super(message, 429, 'RATE_LIMIT');
        this.retryAfter = retryAfter;
    }
}

/**
 * Error handler for responses
 */
export function handleError(error, request) {
    if (error instanceof AppError) {
        const headers = { 'Content-Type': 'application/json' };
        if (error instanceof RateLimitError) {
            headers['Retry-After'] = error.retryAfter.toString();
        }
        return Response.json(
            { 
                error: error.message, 
                code: error.code,
                ...(error.details && { details: error.details })
            },
            { status: error.statusCode, headers }
        );
    }
    
    // Log unexpected errors
    console.error('Unexpected error:', error);
    
    return Response.json(
        { error: 'Internal server error', code: 'INTERNAL_ERROR' },
        { status: 500 }
    );
}
