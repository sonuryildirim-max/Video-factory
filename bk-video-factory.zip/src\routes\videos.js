/**
 * Video Routes - Modernized with conversion_jobs and R2 presigned URLs
 * API endpoints for video upload, processing, and management using the new JobRepository
 */

import { VideoService } from '../services/VideoService.js';
import { handleError } from '../utils/errors.js';

export async function handleVideoRoutes(request, env, ctx) {
    const url = new URL(request.url);
    const path = url.pathname;
    const method = request.method;

    const videoService = new VideoService(env);

    // Extract user ID from authentication (simplified - in real app use JWT)
    const userId = request.headers.get('x-user-id') || 'anonymous';

    try {
        // Route: POST /api/videos/upload/presigned - Generate R2 presigned URL
        if (path === '/api/videos/upload/presigned' && method === 'POST') {
            return await handleGeneratePresignedUrl(request, videoService, userId);
        }

        // Route: POST /api/videos/upload/complete - Complete direct upload
        if (path === '/api/videos/upload/complete' && method === 'POST') {
            return await handleDirectUploadComplete(request, videoService, userId);
        }

        // Route: POST /api/videos/upload/direct/:token - Direct upload to R2 (proxy endpoint)
        if (path.startsWith('/api/videos/upload/direct/') && method === 'POST') {
            const token = path.substring('/api/videos/upload/direct/'.length);
            return await handleDirectUpload(request, videoService, token);
        }

        // Route: GET /api/videos/jobs - List conversion jobs
        if (path === '/api/videos/jobs' && method === 'GET') {
            return await handleGetJobs(request, videoService, userId);
        }

        // Route: GET /api/videos/jobs/:id - Get job details
        if (path.startsWith('/api/videos/jobs/') && method === 'GET') {
            const jobId = path.substring('/api/videos/jobs/'.length);
            if (jobId && !jobId.includes('/')) {
                return await handleGetJobDetails(jobId, videoService, userId);
            }
        }

        // Route: GET /api/videos/statistics
        if (path === '/api/videos/statistics' && method === 'GET') {
            return await handleGetStatistics(request, videoService, userId);
        }

        // Route: POST /api/videos/cleanup (admin only)
        if (path === '/api/videos/cleanup' && method === 'POST') {
            return await handleCleanup(request, videoService, userId);
        }

        // Route: POST /api/jobs/claim - Claim a job (for Hetner agent)
        if (path === '/api/jobs/claim' && method === 'POST') {
            return await handleClaimJob(request, videoService);
        }

        // Route: POST /api/jobs/complete - Complete a job (for Hetner agent)
        if (path === '/api/jobs/complete' && method === 'POST') {
            return await handleCompleteJob(request, videoService);
        }

        // Route: POST /api/jobs/fail - Mark job as failed (for Hetner agent)
        if (path === '/api/jobs/fail' && method === 'POST') {
            return await handleFailJob(request, videoService);
        }

        // Route: POST /api/heartbeat - Worker heartbeat (for Hetner agent)
        if (path === '/api/heartbeat' && method === 'POST') {
            return await handleHeartbeat(request, videoService);
        }

        // Route not found
        return new Response(JSON.stringify({ error: 'Not found' }), {
            status: 404,
            headers: { 'Content-Type': 'application/json' }
        });

    } catch (error) {
        return handleError(error, request);
    }
}

/**
 * Handle video upload
 */
async function handleVideoUpload(request, videoService, userId) {
    const result = await videoService.uploadVideo(request, userId);

    return new Response(JSON.stringify(result), {
        status: 200,
        headers: { 
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        }
    });
}

/**
 * Handle getting videos with filters
 */
async function handleGetVideos(request, videoService, userId) {
    const url = new URL(request.url);
    const searchParams = url.searchParams;

    const filters = {
        search: searchParams.get('search') || '',
        status: searchParams.get('status') || '',
        render_preset: searchParams.get('render_preset') || '',
        uploaded_by: searchParams.get('uploaded_by') || userId, // Default to current user
        start_date: searchParams.get('start_date') || '',
        end_date: searchParams.get('end_date') || '',
        tags: searchParams.get('tags') || '',
        project_name: searchParams.get('project_name') || '',
        page: parseInt(searchParams.get('page') || '1'),
        limit: parseInt(searchParams.get('limit') || '50'),
        sort_by: searchParams.get('sort_by') || 'uploaded_at',
        sort_order: searchParams.get('sort_order') || 'DESC'
    };

    const result = await videoService.searchVideos(filters);

    return new Response(JSON.stringify(result), {
        status: 200,
        headers: { 
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        }
    });
}

/**
 * Handle getting video details
 */
async function handleGetVideoDetails(videoId, videoService, userId) {
    const video = await videoService.getVideoDetails(videoId);

    // Check if user has permission to view this video
    if (video.uploaded_by !== userId && userId !== 'admin') {
        return new Response(JSON.stringify({ error: 'Unauthorized' }), {
            status: 403,
            headers: { 'Content-Type': 'application/json' }
        });
    }

    return new Response(JSON.stringify(video), {
        status: 200,
        headers: { 
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        }
    });
}

/**
 * Handle Hetner server callback
 */
async function handleHetnerCallback(videoId, request, videoService) {
    // Verify callback authentication (simplified)
    const authHeader = request.headers.get('authorization');
    const expectedToken = `Bearer ${videoService.env.HETNER_CALLBACK_TOKEN || 'default-token'}`;
    
    if (authHeader !== expectedToken) {
        return new Response(JSON.stringify({ error: 'Unauthorized' }), {
            status: 401,
            headers: { 'Content-Type': 'application/json' }
        });
    }

    const callbackData = await request.json();
    const result = await videoService.handleHetnerCallback(videoId, callbackData);

    return new Response(JSON.stringify(result), {
        status: 200,
        headers: { 
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        }
    });
}

/**
 * Handle getting statistics
 */
async function handleGetStatistics(request, videoService, userId) {
    const url = new URL(request.url);
    const dateRange = url.searchParams.get('date_range') || '30d';

    const stats = await videoService.getVideoStatistics(dateRange);

    return new Response(JSON.stringify(stats), {
        status: 200,
        headers: { 
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        }
    });
}

/**
 * Handle cleanup of old temporary videos
 */
async function handleCleanup(request, videoService, userId) {
    // Only admin can trigger cleanup
    if (userId !== 'admin') {
        return new Response(JSON.stringify({ error: 'Unauthorized' }), {
            status: 403,
            headers: { 'Content-Type': 'application/json' }
        });
    }

    const url = new URL(request.url);
    const days = parseInt(url.searchParams.get('days') || '3');

    const result = await videoService.cleanupOldVideos(days);

    return new Response(JSON.stringify(result), {
        status: 200,
        headers: { 
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        }
    });
}

/**
 * Handle queue processing (called by Cloudflare Queue consumer)
 */
async function handleQueueProcessing(request, videoService) {
    // Verify this is a queue worker request
    const queueSecret = request.headers.get('x-queue-secret');
    const expectedSecret = videoService.env.QUEUE_WORKER_SECRET || 'queue-secret';
    
    if (queueSecret !== expectedSecret) {
        return new Response(JSON.stringify({ error: 'Unauthorized' }), {
            status: 401,
            headers: { 'Content-Type': 'application/json' }
        });
    }

    const messages = await request.json();
    const results = [];

    for (const message of messages) {
        try {
            const result = await videoService.processVideoFromQueue(message.body);
            results.push({
                success: true,
                video_id: message.body.video_id,
                result
            });
        } catch (error) {
            results.push({
                success: false,
                video_id: message.body.video_id,
                error: error.message
            });
        }
    }

    return new Response(JSON.stringify({ processed: results.length, results }), {
        status: 200,
        headers: { 
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        }
    });
}

/**
 * Handle generating presigned URL for direct R2 upload
 */
async function handleGeneratePresignedUrl(request, videoService, userId) {
    try {
        const result = await videoService.generatePresignedUrl(request, userId);
        
        return new Response(JSON.stringify(result), {
            status: 200,
            headers: { 
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            }
        });
    } catch (error) {
        return new Response(JSON.stringify({ 
            success: false, 
            error: error.message 
        }), {
            status: 400,
            headers: { 
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            }
        });
    }
}

/**
 * Handle direct upload completion
 */
async function handleDirectUploadComplete(request, videoService, userId) {
    try {
        const url = new URL(request.url);
        const token = url.searchParams.get('token') || '';
        
        if (!token) {
            throw new Error('Missing upload token');
        }
        
        const result = await videoService.handleDirectUploadComplete(token, request);
        
        return new Response(JSON.stringify(result), {
            status: 200,
            headers: { 
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            }
        });
    } catch (error) {
        return new Response(JSON.stringify({ 
            success: false, 
            error: error.message 
        }), {
            status: 400,
            headers: { 
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            }
        });
    }
}

/**
 * Handle direct upload to R2 (proxy endpoint)
 */
async function handleDirectUpload(request, videoService, token) {
    const result = await videoService.handleDirectUpload(request, token);
    return result;
}

/**
 * Handle getting jobs with filters
 */
async function handleGetJobs(request, videoService, userId) {
    const url = new URL(request.url);
    const searchParams = url.searchParams;

    const filters = {
        search: searchParams.get('search') || '',
        status: searchParams.get('status') || '',
        quality: searchParams.get('quality') || '',
        uploaded_by: searchParams.get('uploaded_by') || userId,
        start_date: searchParams.get('start_date') || '',
        end_date: searchParams.get('end_date') || '',
        tags: searchParams.get('tags') || '',
        project_name: searchParams.get('project_name') || '',
        page: parseInt(searchParams.get('page') || '1'),
        limit: parseInt(searchParams.get('limit') || '50'),
        sort_by: searchParams.get('sort_by') || 'created_at',
        sort_order: searchParams.get('sort_order') || 'DESC'
    };

    // Since we haven't implemented searchVideos in the modern VideoService yet,
    // we'll return a placeholder response
    return new Response(JSON.stringify({
        jobs: [],
        totalCount: 0,
        page: filters.page,
        totalPages: 1,
        limit: filters.limit
    }), {
        status: 200,
        headers: { 
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        }
    });
}

/**
 * Handle getting job details
 */
async function handleGetJobDetails(jobId, videoService, userId) {
    // For now, return a placeholder
    return new Response(JSON.stringify({
        id: jobId,
        clean_name: 'placeholder',
        status: 'PENDING',
        message: 'Job details endpoint not fully implemented yet'
    }), {
        status: 200,
        headers: { 
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        }
    });
}

/**
 * Handle claiming a job (for Hetner agent)
 */
async function handleClaimJob(request, videoService) {
    try {
        // Verify agent authentication
        const authHeader = request.headers.get('Authorization');
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            return new Response(JSON.stringify({ error: 'Unauthorized' }), {
                status: 401,
                headers: { 'Content-Type': 'application/json' }
            });
        }

        // In production, this would call jobRepo.claimPendingJob()
        // For now, return a mock job
        const mockJob = {
            id: 1,
            original_name: 'test-video.mp4',
            clean_name: 'test-video-abc123.mp4',
            r2_raw_key: 'raw-uploads/1740019200000-abc123-test-video-abc123.mp4',
            quality: '720p',
            file_size_input: 104857600, // 100MB
            download_url: 'https://r2.bilgekarga.com/raw-uploads/1740019200000-abc123-test-video-abc123.mp4'
        };

        return new Response(JSON.stringify(mockJob), {
            status: 200,
            headers: { 
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            }
        });
    } catch (error) {
        return new Response(JSON.stringify({ 
            error: error.message 
        }), {
            status: 500,
            headers: { 
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            }
        });
    }
}

/**
 * Handle completing a job (for Hetner agent)
 */
async function handleCompleteJob(request, videoService) {
    try {
        const data = await request.json();
        const { job_id, public_url, file_size_output, duration, processing_time_seconds, resolution, bitrate, codec, frame_rate, audio_codec, audio_bitrate, ffmpeg_command, ffmpeg_output } = data;

        // In production, this would call jobRepo.completeJob()
        console.log(`Job ${job_id} completed: ${public_url}`);

        return new Response(JSON.stringify({ 
            success: true,
            job_id: job_id,
            message: 'Job completed successfully'
        }), {
            status: 200,
            headers: { 
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            }
        });
    } catch (error) {
        return new Response(JSON.stringify({ 
            error: error.message 
        }), {
            status: 500,
            headers: { 
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            }
        });
    }
}

/**
 * Handle failing a job (for Hetner agent)
 */
async function handleFailJob(request, videoService) {
    try {
        const data = await request.json();
        const { job_id, error_message } = data;

        // In production, this would call jobRepo.failJob()
        console.log(`Job ${job_id} failed: ${error_message}`);

        return new Response(JSON.stringify({ 
            success: true,
            job_id: job_id,
            message: 'Job marked as failed'
        }), {
            status: 200,
            headers: { 
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            }
        });
    } catch (error) {
        return new Response(JSON.stringify({ 
            error: error.message 
        }), {
            status: 500,
            headers: { 
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            }
        });
    }
}

/**
 * Handle worker heartbeat (for Hetner agent)
 */
async function handleHeartbeat(request, videoService) {
    try {
        const data = await request.json();
        const { status, active_jobs, max_workers, queue_size, ip_address, version } = data;

        // In production, this would call jobRepo.updateHeartbeat()
        console.log(`Heartbeat from ${ip_address}: ${status}, active jobs: ${active_jobs}`);

        return new Response(JSON.stringify({ 
            success: true,
            received_at: new Date().toISOString(),
            message: 'Heartbeat received'
        }), {
            status: 200,
            headers: { 
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            }
        });
    } catch (error) {
        return new Response(JSON.stringify({ 
            error: error.message 
        }), {
            status: 500,
            headers: { 
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            }
        });
    }
}
