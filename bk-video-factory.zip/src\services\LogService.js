/**
 * Log Service
 * Handles audit logging
 */

import { sanitizeForLog } from '../utils/security.js';
import { parseUserAgent } from '../utils/userAgent.js';

export class LogService {
    constructor(kvRepo, d1Repo) {
        this.kvRepo = kvRepo;
        this.d1Repo = d1Repo;
    }

    /**
     * Write audit log
     */
    async writeAuditLog(action, details, request) {
        const ip = details.ip || request.headers.get('CF-Connecting-IP') || 'unknown';
        const ua = details.userAgent || request.headers.get('User-Agent') || 'unknown';
        const country = request.cf ? request.cf.country : 'XX';
        const city = request.cf ? request.cf.city : 'Unknown';
        const timestamp = new Date().toISOString();

        // Sanitize details for XSS protection
        const sanitizedDetails = {};
        for (const key in details) {
            if (details.hasOwnProperty(key)) {
                sanitizedDetails[key] = sanitizeForLog(details[key]);
            }
        }

        try {
            await this.d1Repo.writeLog({
                action,
                details: sanitizedDetails,
                ip,
                ua,
                country,
                city,
                timestamp
            });
        } catch (e) {
            console.error('Log write error:', e);
            // Don't throw - logging failures shouldn't break the app
        }
    }

    /**
     * Get logs with filters
     */
    async getLogs(filters) {
        return await this.d1Repo.getLogs(filters);
    }

    /**
     * Cleanup old logs
     */
    async cleanupLogs(days) {
        await this.d1Repo.cleanupLogs(days);
    }
}
