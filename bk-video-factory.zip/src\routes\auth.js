/**
 * Authentication Routes
 */

import { AuthService } from '../services/AuthService.js';
import { LogService } from '../services/LogService.js';
import { KVRepository } from '../repositories/KVRepository.js';
import { D1Repository } from '../repositories/D1Repository.js';
import { CONFIG } from '../config/config.js';
import { isIpBanned, checkRateLimit, incrementFailedAttempts, resetFailedAttempts } from '../middleware/rateLimit.js';
import { handleError } from '../utils/errors.js';
import { SECURITY_HEADERS } from '../config/constants.js';

/**
 * Handle authentication routes
 */
export async function handleAuthRoutes(request, env, ctx) {
    const url = new URL(request.url);
    const ip = request.headers.get('CF-Connecting-IP') || 'unknown';
    const userAgent = request.headers.get('User-Agent') || 'unknown';
    const kvRepo = new KVRepository(env.LINKS);
    const d1Repo = new D1Repository(env.DB);
    const logService = new LogService(kvRepo, d1Repo);
    const authService = new AuthService(env);

    // POST /api/verify
    if (request.method === 'POST' && url.pathname.includes('/verify')) {
        // Check if IP is banned
        if (await isIpBanned(env, ip)) {
            await logService.writeAuditLog('BLOCKED_BANNED_IP', { ip, userAgent }, request);
            return Response.json(
                { error: 'IP adresiniz gecici olarak engellendi.', banned: true },
                {
                    status: 403,
                    headers: { ...SECURITY_HEADERS, 'Retry-After': '3600' }
                }
            );
        }

        // Check global rate limit
        const globalAllowed = await checkRateLimit(
            env,
            'verify:global',
            CONFIG.RATE_LIMITS.VERIFY_GLOBAL_PER_MINUTE,
            60
        );
        if (!globalAllowed) {
            return Response.json(
                { error: 'Sistem yogun. Lutfen biraz bekleyin.' },
                {
                    status: 429,
                    headers: { ...SECURITY_HEADERS, 'Retry-After': '60' }
                }
            );
        }

        // Check IP rate limit
        const verifyAllowed = await checkRateLimit(
            env,
            `verify:${ip}`,
            CONFIG.RATE_LIMITS.VERIFY_PER_MINUTE,
            60
        );
        if (!verifyAllowed) {
            return Response.json(
                { error: 'Cok fazla deneme. Lutfen bekleyin.' },
                {
                    status: 429,
                    headers: { ...SECURITY_HEADERS, 'Retry-After': '60' }
                }
            );
        }

        // Verify credentials
        const authResult = authService.verifyBasicAuth(request);

        if (authResult.valid) {
            await resetFailedAttempts(env, ip);
            ctx.waitUntil(
                logService.writeAuditLog('LOGIN_SUCCESS', {
                    user: authResult.user,
                    ip,
                    userAgent,
                    isRoot: authResult.isRoot
                }, request)
            );
            return Response.json({ success: true, isRoot: authResult.isRoot });
        }

        // Failed login
        const failResult = await incrementFailedAttempts(env, ip);
        ctx.waitUntil(
            logService.writeAuditLog('LOGIN_FAILED', {
                ip,
                userAgent,
                attemptNumber: failResult.attempts,
                banned: failResult.banned
            }, request)
        );

        if (failResult.banned) {
            return Response.json(
                { error: 'Cok fazla basarisiz deneme. 1 saat engellendi.', banned: true },
                {
                    status: 403,
                    headers: { ...SECURITY_HEADERS, 'Retry-After': '3600' }
                }
            );
        }

        const remaining = CONFIG.RATE_LIMITS.MAX_FAILED_ATTEMPTS - failResult.attempts;
        return Response.json(
            { error: 'Unauthorized', remainingAttempts: remaining },
            { status: 401 }
        );
    }

    // GET /login
    if (url.pathname === '/login') {
        // Return login HTML (will be loaded from views later)
        return new Response('Login page - HTML to be added', {
            headers: { ...SECURITY_HEADERS, 'Content-Type': 'text/html;charset=utf-8' }
        });
    }

    return Response.json({ error: 'Not found' }, { status: 404 });
}
