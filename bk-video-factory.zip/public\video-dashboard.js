// Video Dashboard JavaScript
// Complete functionality for video management dashboard

// State
let currentPage = 1;
let totalPages = 1;
let currentFilters = {};
let videosData = [];
let statisticsData = {};

// DOM Elements
const totalVideosEl = document.getElementById('totalVideos');
const completedVideosEl = document.getElementById('completedVideos');
const processingVideosEl = document.getElementById('processingVideos');
const totalStorageEl = document.getElementById('totalStorage');
const videoTrendEl = document.getElementById('videoTrend');
const completedTrendEl = document.getElementById('completedTrend');
const processingTrendEl = document.getElementById('processingTrend');
const storageTrendEl = document.getElementById('storageTrend');
const searchInput = document.getElementById('searchInput');
const statusFilter = document.getElementById('statusFilter');
const presetFilter = document.getElementById('presetFilter');
const videosTable = document.querySelector('.videos-table');
const modal = document.getElementById('videoModal');

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    console.log('Video Dashboard loaded');
    loadStatistics();
    loadVideos();
    setupEventListeners();
});

// Event Listeners
function setupEventListeners() {
    // Filter inputs
    searchInput.addEventListener('input', debounce(() => {
        currentFilters.search = searchInput.value;
        currentPage = 1;
        loadVideos();
    }, 500));

    statusFilter.addEventListener('change', () => {
        currentFilters.status = statusFilter.value;
        currentPage = 1;
        loadVideos();
    });

    presetFilter.addEventListener('change', () => {
        currentFilters.render_preset = presetFilter.value;
        currentPage = 1;
        loadVideos();
    });

    // Date range filters (if added later)
    const dateFrom = document.getElementById('dateFrom');
    const dateTo = document.getElementById('dateTo');
    
    if (dateFrom) {
        dateFrom.addEventListener('change', () => {
            currentFilters.start_date = dateFrom.value;
            currentPage = 1;
            loadVideos();
        });
    }
    
    if (dateTo) {
        dateTo.addEventListener('change', () => {
            currentFilters.end_date = dateTo.value;
            currentPage = 1;
            loadVideos();
        });
    }
}

// Load statistics
async function loadStatistics() {
    try {
        // In real implementation, fetch from API
        // const response = await fetch('/api/videos/statistics?date_range=30d');
        // statisticsData = await response.json();
        
        // Simulated data
        statisticsData = {
            summary: {
                total_videos: 42,
                completed: 35,
                processing: 3,
                failed: 2,
                uploaded: 2,
                total_storage_bytes: 15480000000,
                avg_processing_time: 127,
                unique_uploaders: 3,
                preset_720p: 28,
                preset_1080p: 14
            },
            recent_activity: [
                { date: '2026-02-19', uploads: 3, completed: 2 },
                { date: '2026-02-18', uploads: 2, completed: 3 },
                { date: '2026-02-17', uploads: 4, completed: 4 },
                { date: '2026-02-16', uploads: 1, completed: 1 },
                { date: '2026-02-15', uploads: 3, completed: 2 }
            ],
            top_uploaders: [
                { uploaded_by: 'admin', upload_count: 28, total_size: 11200000000 },
                { uploaded_by: 'user1', upload_count: 10, total_size: 3500000000 },
                { uploaded_by: 'user2', upload_count: 4, total_size: 780000000 }
            ]
        };

        updateStatisticsUI();
    } catch (error) {
        console.error('Error loading statistics:', error);
        showNotification('İstatistikler yüklenirken hata oluştu', 'error');
    }
}

// Update statistics UI
function updateStatisticsUI() {
    const stats = statisticsData.summary;
    
    totalVideosEl.textContent = stats.total_videos;
    completedVideosEl.textContent = stats.completed;
    processingVideosEl.textContent = stats.processing;
    
    // Format storage
    const storageGB = (stats.total_storage_bytes / (1024 * 1024 * 1024)).toFixed(1);
    totalStorageEl.textContent = `${storageGB} GB`;
    
    // Calculate trends (simulated)
    const videoTrend = Math.floor(Math.random() * 20) + 5;
    const completedTrend = Math.floor(Math.random() * 15) + 8;
    const processingTrend = 0;
    const storageTrend = Math.floor(Math.random() * 25) + 10;
    
    videoTrendEl.textContent = `+${videoTrend}%`;
    completedTrendEl.textContent = `+${completedTrend}%`;
    processingTrendEl.textContent = processingTrend === 0 ? '0' : `+${processingTrend}%`;
    storageTrendEl.textContent = `+${storageTrend}%`;
    
    // Update trend colors
    updateTrendColor(videoTrendEl, videoTrend);
    updateTrendColor(completedTrendEl, completedTrend);
    updateTrendColor(processingTrendEl, processingTrend);
    updateTrendColor(storageTrendEl, storageTrend);
}

function updateTrendColor(element, trend) {
    element.classList.remove('trend-up', 'trend-down', 'trend-neutral');
    
    if (trend > 0) {
        element.classList.add('trend-up');
    } else if (trend < 0) {
        element.classList.add('trend-down');
    } else {
        element.classList.add('trend-neutral');
    }
}

// Load videos with filters
async function loadVideos() {
    try {
        // Build query parameters
        const params = new URLSearchParams({
            page: currentPage,
            limit: 20,
            ...currentFilters
        });
        
        // In real implementation, fetch from API
        // const response = await fetch(`/api/videos?${params}`);
        // const data = await response.json();
        
        // Simulated data
        const data = generateMockVideos();
        
        videosData = data.videos;
        totalPages = data.totalPages || 1;
        
        updateVideosTable();
        updatePagination();
        
    } catch (error) {
        console.error('Error loading videos:', error);
        showNotification('Videolar yüklenirken hata oluştu', 'error');
    }
}

// Generate mock videos for demo
function generateMockVideos() {
    const mockVideos = [];
    const statuses = ['uploaded', 'processing', 'completed', 'failed'];
    const presets = ['720p_web', '1080p_web'];
    const users = ['admin', 'user1', 'user2'];
    
    const videoNames = [
        'gunes-gozlugu-tanitimi',
        'urun-demo-2026',
        'egitim-videosu',
        'tanitim-reklami',
        'konferans-kaydi',
        'webinar-kaydi',
        'musteri-testimonials',
        'sirket-tanitimi',
        'urun-kullanim-kilavuzu',
        'teknik-demo'
    ];
    
    const originalNames = [
        'güneş gözlüğü.mp4',
        'ürün demo 2026.mov',
        'eğitim videosu.avi',
        'tanıtım reklamı.mp4',
        'konferans kaydı.mkv',
        'webinar kaydı.webm',
        'müşteri testimonials.mp4',
        'şirket tanıtımı.mov',
        'ürün kullanım kılavuzu.avi',
        'teknik demo.mp4'
    ];
    
    for (let i = 0; i < 20; i++) {
        const status = statuses[Math.floor(Math.random() * statuses.length)];
        const preset = presets[Math.floor(Math.random() * presets.length)];
        const user = users[Math.floor(Math.random() * users.length)];
        const nameIndex = Math.floor(Math.random() * videoNames.length);
        
        mockVideos.push({
            id: `vid_${Date.now()}_${i}`,
            normalized_name: `${videoNames[nameIndex]}-${Math.random().toString(36).substr(2, 8)}.mp4`,
            original_name: originalNames[nameIndex],
            status: status,
            render_preset: preset,
            file_size: Math.floor(Math.random() * 500000000) + 100000000, // 100MB - 600MB
            duration: Math.floor(Math.random() * 600) + 60, // 1-10 minutes
            resolution: preset === '720p_web' ? '1280x720' : '1920x1080',
            uploaded_by: user,
            uploaded_at: new Date(Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000).toISOString(),
            processing_completed_at: status === 'completed' ? new Date().toISOString() : null,
            tags: 'ürün,tanıtım,eğitim',
            project_name: '2026 Tanıtım Videoları',
            notes: 'Demo video içeriği'
        });
    }
    
    return {
        videos: mockVideos,
        totalCount: 42,
        page: currentPage,
        totalPages: 3,
        limit: 20
    };
}

// Update videos table
function updateVideosTable() {
    const tableBody = videosTable.querySelector('.table-body') || document.createElement('div');
    tableBody.className = 'table-body';
    tableBody.innerHTML = '';
    
    videosData.forEach(video => {
        const row = createVideoRow(video);
        tableBody.appendChild(row);
    });
    
    if (!videosTable.querySelector('.table-body')) {
        videosTable.appendChild(tableBody);
    }
}

// Create video table row
function createVideoRow(video) {
    const row = document.createElement('div');
    row.className = 'table-row';
    
    // Status badge
    const statusText = {
        'uploaded': 'Yüklendi',
        'processing': 'İşleniyor',
        'completed': 'Tamamlandı',
        'failed': 'Başarısız'
    }[video.status] || video.status;
    
    // Format file size
    const fileSizeMB = (video.file_size / (1024 * 1024)).toFixed(1);
    
    // Format date
    const uploadDate = new Date(video.uploaded_at).toLocaleDateString('tr-TR');
    
    // Thumbnail icon based on status
    const thumbnailIcon = {
        'uploaded': '📤',
        'processing': '⏳',
        'completed': '✅',
        'failed': '❌'
    }[video.status] || '📹';
    
    row.innerHTML = `
        <div class="table-cell">
            <div class="video-thumbnail">${thumbnailIcon}</div>
            <div class="video-info">
                <div class="video-name">${escapeHtml(video.normalized_name)}</div>
                <div class="video-original">${escapeHtml(video.original_name)}</div>
            </div>
        </div>
        <div class="table-cell">
            <span class="status-badge status-${video.status}">${statusText}</span>
        </div>
        <div class="table-cell">${video.render_preset === '720p_web' ? '720p Web' : '1080p Web'}</div>
        <div class="table-cell">${fileSizeMB} MB</div>
        <div class="table-cell">${uploadDate}</div>
        <div class="table-cell">
            <div class="action-buttons">
                <button class="action-btn action-view" onclick="viewVideoDetails('${video.id}')">
                    👁️ Görüntüle
                </button>
                ${video.status === 'completed' ? `
                    <button class="action-btn action-download" onclick="downloadVideo('${video.id}')">
                        ⬇️ İndir
                    </button>
                ` : ''}
                <button class="action-btn action-delete" onclick="deleteVideo('${video.id}')">
                    🗑️ Sil
                </button>
            </div>
        </div>
    `;
    
    return row;
}

// Update pagination
function updatePagination() {
    let pagination = document.querySelector('.pagination');
    if (!pagination) {
        pagination = document.createElement('div');
        pagination.className = 'pagination';
        videosTable.parentNode.insertBefore(pagination, videosTable.nextSibling);
    }
    
    pagination.innerHTML = `
        <button class="page-btn" onclick="goToPage(${currentPage - 1})" ${currentPage === 1 ? 'disabled' : ''}>
            ← Önceki
        </button>
        <div class="page-info">
            Sayfa ${currentPage} / ${totalPages}
        </div>
        <button class="page-btn" onclick="goToPage(${currentPage + 1})" ${currentPage === totalPages ? 'disabled' : ''}>
            Sonraki →
        </button>
    `;
}

// Navigation functions
function goToPage(page) {
    if (page < 1 || page > totalPages) return;
    currentPage = page;
    loadVideos();
}

function refreshData() {
    loadStatistics();
    loadVideos();
    showNotification('Veriler yenilendi', 'success');
}

// Export data
function exportData() {
    // Create CSV content
    const headers = ['ID', 'Orijinal Ad', 'Normalize Edilmiş Ad', 'Durum', 'Render Preseti', 'Boyut (MB)', 'Süre (sn)', 'Yükleyen', 'Yükleme Tarihi'];
    
    const csvRows = [
        headers.join(','),
        ...videosData.map(video => [
            video.id,
            `"${video.original_name}"`,
            `"${video.normalized_name}"`,
            video.status,
            video.render_preset,
            (video.file_size / (1024 * 1024)).toFixed(2),
            video.duration || '0',
            video.uploaded_by,
            new Date(video.uploaded_at).toLocaleDateString('tr-TR')
        ].join(','))
    ];
    
    const csvContent = csvRows.join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    
    const link = document.createElement('a');
    link.href = url;
    link.download = `videolar_${new Date().toISOString().slice(0, 10)}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    showNotification('CSV dosyası indiriliyor...', 'success');
}

// View video details
function viewVideoDetails(videoId) {
    const video = videosData.find(v => v.id === videoId);
    if (!video) return;
    
    // Create or update modal
    let modal = document.getElementById('videoModal');
    if (!modal) {
        modal = document.createElement('div');
        modal.id = 'videoModal';
        modal.className = 'modal';
        document.body.appendChild(modal);
    }
    
    // Format dates
    const uploadDate = new Date(video.uploaded_at).toLocaleString('tr-TR');
    const processDate = video.processing_completed_at 
        ? new Date(video.processing_completed_at).toLocaleString('tr-TR')
        : 'Henüz işlenmedi';
    
    // Format file size
    const fileSizeMB = (video.file_size / (1024 * 1024)).toFixed(1);
    const fileSizeGB = (video.file_size / (1024 * 1024 * 1024)).toFixed(2);
    
    modal.innerHTML = `
        <div class="modal-content">
            <div class="modal-header">
                <h2>🎬 Video Detayları</h2>
                <button class="modal-close" onclick="closeModal()">×</button>
            </div>
            
            <div class="modal-details">
                <div class="detail-group">
                    <div class="detail-label">Video ID</div>
                    <div class="detail-value">${video.id}</div>
                </div>
                <div class="detail-group">
                    <div class="detail-label">Orijinal Ad</div>
                    <div class="detail-value">${escapeHtml(video.original_name)}</div>
                </div>
                <div class="detail-group">
                    <div class="detail-label">Normalize Edilmiş Ad</div>
                    <div class="detail-value">${escapeHtml(video.normalized_name)}</div>
                </div>
                <div class="detail-group">
                    <div class="detail-label">Durum</div>
                    <div class="detail-value">
                        <span class="status-badge status-${video.status}">
                            ${video.status === 'uploaded' ? 'Yüklendi' : 
                              video.status === 'processing' ? 'İşleniyor' :
                              video.status === 'completed' ? 'Tamamlandı' : 'Başarısız'}
                        </span>
                    </div>
                </div>
                <div class="detail-group">
                    <div class="detail-label">Render Preseti</div>
                    <div class="detail-value">${video.render_preset === '720p_web' ? '720p Web Optimize' : '1080p Web Optimize'}</div>
                </div>
                <div class="detail-group">
                    <div class="detail-label">Boyut</div>
                    <div class="detail-value">${fileSizeMB} MB (${fileSizeGB} GB)</div>
                </div>
                <div class="detail-group">
                    <div class="detail-label">Yükleme Tarihi</div>
                    <div class="detail-value">${uploadDate}</div>
                </div>
                <div class="detail-group">
                    <div class="detail-label">İşlem Süresi</div>
                    <div class="detail-value">${video.duration || 'Bilinmiyor'} saniye</div>
                </div>
                <div class="detail-group">
                    <div class="detail-label">Çözünürlük</div>
                    <div class="detail-value">${video.resolution || 'Bilinmiyor'}</div>
                </div>
                <div class="detail-group">
                    <div class="detail-label">Yükleyen</div>
                    <div class="detail-value">${video.uploaded_by}</div>
                </div>
                <div class="detail-group">
                    <div class="detail-label">Etiketler</div>
                    <div class="detail-value">${video.tags || 'Yok'}</div>
                </div>
                <div class="detail-group">
                    <div class="detail-label">Proje Adı</div>
                    <div class="detail-value">${video.project_name || 'Yok'}</div>
                </div>
                <div class="detail-group">
                    <div class="detail-label">İşlem Tamamlanma Tarihi</div>
                    <div class="detail-value">${processDate}</div>
                </div>
                ${video.status === 'completed' ? `
                <div class="detail-group">
                    <div class="detail-label">Video URL</div>
                    <div class="detail-value">
                        <a href="https://r2.bilgekarga.com/videos/${video.normalized_name}" target="_blank">
                            https://r2.bilgekarga.com/videos/${video.normalized_name}
                        </a>
                    </div>
                </div>
                ` : ''}
            </div>
            
            <div class="logs-container">
                <h4>📝 İşlem Logları</h4>
                <div class="log-entry">
                    <div class="log-time">${uploadDate}</div>
                    <div class="log-message">Video yüklendi: ${escapeHtml(video.original_name)}</div>
                </div>
                ${video.status === 'processing' || video.status === 'completed' ? `
                <div class="log-entry">
                    <div class="log-time">${new Date(video.uploaded_at).toLocaleString('tr-TR')}</div>
                    <div class="log-message">Dosya normalizasyonu: ${escapeHtml(video.normalized_name)}</div>
                </div>
                <div class="log-entry">
                    <div class="log-time">${new Date(video.uploaded_at).toLocaleString('tr-TR')}</div>
                    <div class="log-message">FFmpeg işlemi başlatıldı (${video.render_preset === '720p_web' ? '720p Web Optimize' : '1080p Web Optimize'})</div>
                </div>
                ` : ''}
                ${video.status === 'completed' ? `
                <div class="log-entry">
                    <div class="log-time">${processDate}</div>
                    <div class="log-message">Video işlendi ve R2'ye yüklendi</div>
                </div>
                <div class="log-entry">
                    <div class="log-time">${processDate}</div>
                    <div class="log-message">İşlem tamamlandı</div>
                </div>
                ` : video.status === 'failed' ? `
                <div class="log-entry">
                    <div class="log-time">${uploadDate}</div>
                    <div class="log-message">Video işlenirken hata oluştu</div>
                </div>
                ` : ''}
            </div>
            
            <div class="actions" style="margin-top: 20px;">
                ${video.status === 'completed' ? `
                <button class="btn btn-primary" onclick="downloadVideo('${video.id}')">
                    ⬇️ Video İndir
                </button>
                ` : ''}
                <button class="btn btn-secondary" onclick="retryProcessing('${video.id}')">
                    🔄 İşlemi Yeniden Dene
                </button>
            </div>
        </div>
    `;
    
    modal.classList.add('show');
}

// Close modal
function closeModal() {
    const modal = document.getElementById('videoModal');
    if (modal) {
        modal.classList.remove('show');
    }
}

// Close stats modal
function closeStatsModal() {
    const modal = document.getElementById('statsModal');
    if (modal) {
        modal.classList.remove('show');
    }
}

// Show stats modal
function showStatsModal() {
    let modal = document.getElementById('statsModal');
    if (!modal) {
        modal = document.createElement('div');
        modal.id = 'statsModal';
        modal.className = 'modal';
        document.body.appendChild(modal);
    }
    
    const stats = statisticsData.summary || {};
    const recent = statisticsData.recent_activity || [];
    const topUploaders = statisticsData.top_uploaders || [];
    
    const storageGB = (stats.total_storage_bytes || 0) / (1024 * 1024 * 1024);
    const avgProcessingTime = stats.avg_processing_time || 0;
    
    modal.innerHTML = `
        <div class="modal-content">
            <div class="modal-header">
                <h2>📈 Detaylı İstatistikler</h2>
                <button class="modal-close" onclick="closeStatsModal()">×</button>
            </div>
            
            <div class="modal-details">
                <div class="detail-group">
                    <div class="detail-label">Toplam Video</div>
                    <div class="detail-value">${stats.total_videos || 0}</div>
                </div>
                <div class="detail-group">
                    <div class="detail-label">İşlenmiş Video</div>
                    <div class="detail-value">${stats.completed || 0} (${stats.total_videos ? Math.round((stats.completed / stats.total_videos) * 100) : 0}%)</div>
                </div>
                <div class="detail-group">
                    <div class="detail-label">İşleniyor</div>
                    <div class="detail-value">${stats.processing || 0} (${stats.total_videos ? Math.round((stats.processing / stats.total_videos) * 100) : 0}%)</div>
                </div>
                <div class="detail-group">
                    <div class="detail-label">Başarısız</div>
                    <div class="detail-value">${stats.failed || 0} (${stats.total_videos ? Math.round((stats.failed / stats.total_videos) * 100) : 0}%)</div>
                </div>
                <div class="detail-group">
                    <div class="detail-label">Yüklendi</div>
                    <div class="detail-value">${stats.uploaded || 0} (${stats.total_videos ? Math.round((stats.uploaded / stats.total_videos) * 100) : 0}%)</div>
                </div>
                <div class="detail-group">
                    <div class="detail-label">Toplam Depolama</div>
                    <div class="detail-value">${storageGB.toFixed(1)} GB</div>
                </div>
                <div class="detail-group">
                    <div class="detail-label">Ortalama İşlem Süresi</div>
                    <div class="detail-value">${avgProcessingTime} saniye</div>
                </div>
                <div class="detail-group">
                    <div class="detail-label">720p Preset</div>
                    <div class="detail-value">${stats.preset_720p || 0} video (${stats.total_videos ? Math.round((stats.preset_720p / stats.total_videos) * 100) : 0}%)</div>
                </div>
                <div class="detail-group">
                    <div class="detail-label">1080p Preset</div>
                    <div class="detail-value">${stats.preset_1080p || 0} video (${stats.total_videos ? Math.round((stats.preset_1080p / stats.total_videos) * 100) : 0}%)</div>
                </div>
                <div class="detail-group">
                    <div class="detail-label">Benzersiz Yükleyen</div>
                    <div class="detail-value">${stats.unique_uploaders || 0} kullanıcı</div>
                </div>
            </div>
            
            ${recent.length > 0 ? `
            <div class="logs-container">
                <h4>📅 Son 5 Günün Aktivitesi</h4>
                ${recent.map(day => `
                <div class="log-entry">
                    <div class="log-time">${day.date}</div>
                    <div class="log-message">${day.uploads} yeni video, ${day.completed} işlenmiş video</div>
                </div>
                `).join('')}
            </div>
            ` : ''}
            
            ${topUploaders.length > 0 ? `
            <div class="logs-container">
                <h4>👥 En Çok Video Yükleyenler</h4>
                ${topUploaders.map(uploader => `
                <div class="log-entry">
                    <div class="log-time">${uploader.uploaded_by}</div>
                    <div class="log-message">${uploader.upload_count} video (${(uploader.total_size / (1024 * 1024 * 1024)).toFixed(2)} GB)</div>
                </div>
                `).join('')}
            </div>
            ` : ''}
        </div>
    `;
    
    modal.classList.add('show');
}

// Download video
function downloadVideo(videoId) {
    const video = videosData.find(v => v.id === videoId);
    if (!video) return;
    
    // In real implementation, this would redirect to download URL or trigger download
    showNotification(`${video.normalized_name} indiriliyor...`, 'success');
    
    // Simulate download
    setTimeout(() => {
        window.open(`https://r2.bilgekarga.com/videos/${video.normalized_name}`, '_blank');
    }, 500);
}

// Delete video
function deleteVideo(videoId) {
    if (!confirm('Bu videoyu silmek istediğinize emin misiniz? Bu işlem geri alınamaz.')) {
        return;
    }
    
    // In real implementation, this would call delete API
    showNotification('Video siliniyor...', 'info');
    
    // Simulate deletion
    setTimeout(() => {
        videosData = videosData.filter(v => v.id !== videoId);
        updateVideosTable();
        loadStatistics(); // Refresh stats
        showNotification('Video başarıyla silindi', 'success');
    }, 1000);
}

// Retry processing
function retryProcessing(videoId) {
    const video = videosData.find(v => v.id === videoId);
    if (!video) return;
    
    // In real implementation, this would call retry API
    showNotification('Video işlemi yeniden başlatılıyor...', 'info');
    
    // Simulate retry
    setTimeout(() => {
        video.status = 'processing';
        updateVideosTable();
        showNotification('Video işlemi yeniden başlatıldı', 'success');
    }, 500);
}

// Utility functions
function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

function showNotification(message, type = 'info') {
    // Remove existing notification
    const existing = document.querySelector('.notification');
    if (existing) {
        existing.remove();
    }
    
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    
    // Add styles
    const styles = document.createElement('style');
    styles.textContent = `
        .notification {
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 15px 20px;
            border-radius: 10px;
            color: white;
            font-weight: 500;
            z-index: 9999;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
            animation: slideIn 0.3s ease;
            max-width: 400px;
            word-wrap: break-word;
        }
        .notification-info { background: linear-gradient(135deg, #4f46e5, #7c3aed); }
        .notification-success { background: linear-gradient(135deg, #16a34a, #22c55e); }
        .notification-error { background: linear-gradient(135deg, #dc2626, #ef4444); }
        .notification-warning { background: linear-gradient(135deg, #d97706, #f59e0b); }
        @keyframes slideIn {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }
    `;
    document.head.appendChild(styles);
    
    // Icon based on type
    const icon = {
        'info': 'ℹ️',
        'success': '✅',
        'error': '❌',
        'warning': '⚠️'
    }[type] || 'ℹ️';
    
    notification.innerHTML = `${icon} ${message}`;
    document.body.appendChild(notification);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        if (notification.parentNode) {
            notification.style.animation = 'slideOut 0.3s ease';
            setTimeout(() => notification.remove(), 300);
        }
    }, 5000);
}

// Initialize charts (placeholder)
function initCharts() {
    // This would initialize Chart.js charts
    console.log('Charts would be initialized here with Chart.js');
}

// Export to global scope for HTML onclick handlers
window.refreshData = refreshData;
window.exportData = exportData;
window.showStatsModal = showStatsModal;
window.viewVideoDetails = viewVideoDetails;
window.closeModal = closeModal;
window.closeStatsModal = closeStatsModal;
window.downloadVideo = downloadVideo;
window.deleteVideo = deleteVideo;
window.goToPage = goToPage;
window.retryProcessing = retryProcessing;
