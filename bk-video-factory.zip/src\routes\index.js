/**
 * Route Dispatcher
 * Main routing logic
 */

import { handleAuthRoutes } from './auth.js';
import { handleLinkRoutes, handleLinkRedirect } from './links.js';
import { handleAnalyticsRoutes } from './analytics.js';
import { handleLogRoutes } from './logs.js';
import { handleAdminRoutes } from './admin.js';
import { handleVideoRoutes } from './videos.js';
import { handleError } from '../utils/errors.js';
import { CONFIG } from '../config/config.js';

/**
 * Route request to appropriate handler
 */
export async function routeRequest(request, env, ctx) {
    const url = new URL(request.url);
    const path = url.pathname.slice(1).split('/')[0];
    const fullPath = url.pathname;

    try {
        // Health check
        if (path === 'health') {
            return Response.json({
                status: 'healthy',
                version: '2.0.0',
                timestamp: Date.now()
            });
        }

        // Root redirect
        if (!path || path === '') {
            return Response.redirect(CONFIG.MAIN_SITE, 302);
        }

        // Auth routes
        if (fullPath === '/login' || fullPath.startsWith('/api/verify')) {
            return await handleAuthRoutes(request, env, ctx);
        }

        // Admin routes
        if (fullPath === '/admin' || fullPath.startsWith('/api/admin/')) {
            return await handleAdminRoutes(request, env, ctx);
        }

        // Link routes
        if (fullPath.startsWith('/api/shorten') ||
            fullPath.startsWith('/api/stats') ||
            fullPath.startsWith('/api/links')) {
            return await handleLinkRoutes(request, env, ctx);
        }

        // Analytics routes
        if (fullPath.startsWith('/api/analytics')) {
            return await handleAnalyticsRoutes(request, env, ctx);
        }

        // Log routes
        if (fullPath === '/logs' || fullPath.startsWith('/api/logs')) {
            return await handleLogRoutes(request, env, ctx);
        }

        // Video routes
        if (fullPath.startsWith('/api/videos')) {
            return await handleVideoRoutes(request, env, ctx);
        }

        // Link redirect (catch-all for slugs)
        if (path && !['api', 'favicon.ico', 'robots.txt', 'login', 'admin', 'logs', 'videos'].includes(path)) {
            return await handleLinkRedirect(request, env, ctx, path);
        }

        // Default redirect
        return Response.redirect(CONFIG.MAIN_SITE, 302);

    } catch (error) {
        return handleError(error, request);
    }
}