# BK-VF (Bilge Karga Video Factory) - Git Setup Instructions

## 📋 Proje Durumu

Proje başarıyla refactor edildi ve aşağıdaki özellikler eklendi:

### ✅ Tamamlanan İyileştirmeler

1. **R2 Presigned URL Desteği**
   - 100MB limiti kaldırıldı (1GB+ destek)
   - Doğrudan Cloudflare R2'ye yükleme
   - Token tabanlı güvenlik (15 dakika TTL)

2. **Atomik Job Processing**
   - `conversion_jobs` tablosu ile atomic işlemler
   - Race condition güvencesi (UPDATE ... RETURNING)
   - Job lifecycle: PENDING → PROCESSING → COMPLETED/FAILED

3. **Exponential Backoff Polling**
   - Dinamik polling aralığı (10s-120s)
   - İş yüküne göre otomatik ayarlama
   - CPU optimizasyonu

4. **Multi-threaded Python Agent**
   - 4 worker thread havuzu
   - Paralel FFmpeg işleme
   - Heartbeat monitoring
   - Graceful shutdown

5. **Kapsamlı Monitoring**
   - Job logs tablosu
   - Daily statistics
   - Worker heartbeat tracking
   - Search view (jobs_search_view)

## ⚠️ Git Kurulumu Gerekli

Sistemde Git kurulu değil. Aşağıdaki adımları takip edin:

### 1. Git Kurulumu
1. Git'i indirin: https://git-scm.com/download/win
2. Kurulum sırasında "Git from the command line and also from 3rd-party software" seçeneğini seçin
3. Varsayılan ayarlarla kurulumu tamamlayın

### 2. GitHub Repository Oluşturma
1. https://github.com/sonuryildirim-max adresine gidin
2. "New repository" butonuna tıklayın
3. Repository adı: `bk-video-factory`
4. Public/Private seçin
5. "Create repository" butonuna tıklayın

### 3. Manuel Git Komutları (Git kurulduktan sonra)

Proje dizininde aşağıdaki komutları sırayla çalıştırın:

```bash
cd C:\Users\onur\Desktop\bilge-karga-refactored

# 1. Git repository başlat
git init

# 2. Tüm dosyaları ekle (.gitignore'daki dosyalar hariç)
git add .

# 3. İlk commit'i oluştur
git commit -m "Initial refactor and video factory setup"

# 4. Ana branch'i main olarak ayarla
git branch -M main

# 5. GitHub repository'sini ekle
git remote add origin https://github.com/sonuryildirim-max/bk-video-factory.git

# 6. GitHub'a yükle
git push -u origin main
```

### 4. Alternatif: PowerShell Script

Git kurulduktan sonra PowerShell'de şu komutu çalıştırabilirsiniz:

```powershell
cd C:\Users\onur\Desktop\bilge-karga-refactored
.\setup_git.bat
```

## 📁 Proje Dosya Yapısı

```
bilge-karga-refactored/
├── src/                          # Ana kaynak kodları
│   ├── repositories/            # Database repositories
│   │   ├── JobRepository.js     # Modern job repository
│   │   └── VideoRepository.js   # Legacy video repository
│   ├── services/               # Business logic
│   │   ├── JobService.js       # Job management service
│   │   └── VideoService.js     # Modern video service (R2 support)
│   └── routes/                 # API routes
│       └── videos.js           # Modern API endpoints
├── hetner-agent/               # Python processing agent
│   ├── agent_multi_thread.py   # Multi-threaded agent
│   ├── agent_complete.py       # Complete agent
│   └── agent.py               # Legacy agent
├── migrations/                 # Database migrations
│   ├── 001_add_videos_table.sql
│   └── 002_add_conversion_jobs_table.sql  # Modern migration
├── public/                     # Frontend files
│   ├── video-upload.html      # Upload interface
│   ├── video-dashboard.html   # Dashboard
│   └── *.js                   # Frontend JavaScript
├── .gitignore                 # Git ignore file
├── setup_git.bat              # Git setup script
├── test_migration.py          # Migration test script
├── test.db                    # Test database (gitignore'da)
└── README.md                  # Proje dokümantasyonu
```

## 🔧 Teknik Özellikler

### R2 Presigned URL Flow
```
1. Client → POST /api/videos/upload/presigned
2. Server → R2.createPresignedUpload() → {url, token, expiresAt}
3. Client → PUT {url} (direct to R2, no size limit)
4. Client → POST /api/videos/upload/complete?token={token}
5. Server → Creates PENDING job in conversion_jobs
```

### Exponential Backoff Algorithm
```python
BASE_INTERVAL = 10      # seconds — intense period
MAX_INTERVAL = 120      # seconds — idle period  
IDLE_THRESHOLD = 5      # consecutive idle returns count

if idle_count >= IDLE_THRESHOLD:
    wait = min(BASE_INTERVAL * (2 ** min(idle_count - IDLE_THRESHOLD, 4)), MAX_INTERVAL)
else:
    wait = BASE_INTERVAL
```

### Atomic Job Claim Pattern
```sql
-- Race condition yok!
UPDATE conversion_jobs 
SET status = 'PROCESSING', 
    started_at = CURRENT_TIMESTAMP,
    worker_id = ?
WHERE status = 'PENDING' 
LIMIT 1 
RETURNING *;
```

## 🚀 Dağıtım Hazırlığı

Proje şu anda dağıtıma hazır durumda:

1. **Cloudflare Workers + D1 + R2** uyumlu
2. **Windows Service** ready (NSSM ile)
3. **Environment variables** ile konfigürasyon
4. **Kapsamlı logging** ve monitoring
5. **Scalable architecture** (production ready)

## 📞 İletişim

Git kurulumu tamamlandıktan sonra proje GitHub'a yüklenebilir. Herhangi bir sorun olursa yardıma hazırım!