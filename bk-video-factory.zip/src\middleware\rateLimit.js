/**
 * Rate Limiting Middleware
 */

import { CONFIG } from '../config/config.js';
import { RateLimitError } from '../utils/errors.js';
import { KVRepository } from '../repositories/KVRepository.js';

/**
 * Check rate limit
 */
export async function checkRateLimit(env, key, maxRequests, windowSeconds) {
    const kvRepo = new KVRepository(env.LINKS);
    return await kvRepo.checkRateLimit(key, maxRequests, windowSeconds);
}

/**
 * Check if IP is banned
 */
export async function isIpBanned(env, ip) {
    const kvRepo = new KVRepository(env.LINKS);
    return await kvRepo.isIpBanned(ip);
}

/**
 * Increment failed attempts
 */
export async function incrementFailedAttempts(env, ip) {
    const kvRepo = new KVRepository(env.LINKS);
    return await kvRepo.incrementFailedAttempts(
        ip,
        CONFIG.RATE_LIMITS.MAX_FAILED_ATTEMPTS,
        CONFIG.RATE_LIMITS.BAN_DURATION_SECONDS
    );
}

/**
 * Reset failed attempts
 */
export async function resetFailedAttempts(env, ip) {
    const kvRepo = new KVRepository(env.LINKS);
    await kvRepo.resetFailedAttempts(ip);
}
