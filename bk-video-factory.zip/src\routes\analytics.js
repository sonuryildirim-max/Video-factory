/**
 * Analytics Routes
 */

import { AnalyticsService } from '../services/AnalyticsService.js';
import { D1Repository } from '../repositories/D1Repository.js';
import { requireRoot } from '../middleware/auth.js';
import { handleError } from '../utils/errors.js';
import { SECURITY_HEADERS } from '../config/constants.js';

/**
 * Handle analytics routes
 */
export async function handleAnalyticsRoutes(request, env, ctx) {
    const url = new URL(request.url);
    const d1Repo = new D1Repository(env.DB);
    const analyticsService = new AnalyticsService(d1Repo);

    try {
        // GET /api/analytics
        if (request.method === 'GET' && url.pathname.includes('/analytics')) {
            await requireRoot(request, env);

            const data = await analyticsService.getAnalyticsData();
            return Response.json(data, { headers: SECURITY_HEADERS });
        }

        return Response.json({ error: 'Not found' }, { status: 404 });
    } catch (error) {
        return handleError(error, request);
    }
}
