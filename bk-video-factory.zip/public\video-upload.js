// Video Upload JavaScript
// Complete functionality for video upload interface

// DOM Elements
const uploadArea = document.getElementById('uploadArea');
const fileInput = document.getElementById('fileInput');
const browseBtn = document.getElementById('browseBtn');
const fileInfo = document.getElementById('fileInfo');
const fileDetails = document.getElementById('fileDetails');
const uploadBtn = document.getElementById('uploadBtn');
const progressContainer = document.getElementById('progressContainer');
const progressFill = document.getElementById('progressFill');
const progressPercent = document.getElementById('progressPercent');
const resultContainer = document.getElementById('resultContainer');
const resultContent = document.getElementById('resultContent');
const presetButtons = document.querySelectorAll('.preset-btn');
const tagsInput = document.getElementById('tags');
const projectNameInput = document.getElementById('projectName');
const notesInput = document.getElementById('notes');

// State
let selectedFile = null;
let selectedPreset = '720p_web';
let uploadInProgress = false;
let videoId = null;

// Event Listeners
browseBtn.addEventListener('click', () => fileInput.click());
fileInput.addEventListener('change', handleFileSelect);
uploadArea.addEventListener('click', () => fileInput.click());

// Drag and drop
['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
    uploadArea.addEventListener(eventName, preventDefaults, false);
});

function preventDefaults(e) {
    e.preventDefault();
    e.stopPropagation();
}

['dragenter', 'dragover'].forEach(eventName => {
    uploadArea.addEventListener(eventName, highlight, false);
});

['dragleave', 'drop'].forEach(eventName => {
    uploadArea.addEventListener(eventName, unhighlight, false);
});

function highlight() {
    uploadArea.classList.add('dragover');
}

function unhighlight() {
    uploadArea.classList.remove('dragover');
}

uploadArea.addEventListener('drop', handleDrop, false);

// Preset selection
presetButtons.forEach(btn => {
    btn.addEventListener('click', () => {
        presetButtons.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        selectedPreset = btn.dataset.preset;
    });
});

// File handling
function handleFileSelect(e) {
    const file = e.target.files[0];
    if (file) handleFile(file);
}

function handleDrop(e) {
    const dt = e.dataTransfer;
    const file = dt.files[0];
    if (file) handleFile(file);
}

function handleFile(file) {
    // Validate file
    const allowedTypes = ['video/mp4', 'video/quicktime', 'video/x-msvideo', 'video/x-matroska', 'video/webm'];
    const allowedExtensions = ['.mp4', '.mov', '.avi', '.mkv', '.webm'];
    
    const fileExt = '.' + file.name.split('.').pop().toLowerCase();
    
    if (!allowedExtensions.includes(fileExt) && !allowedTypes.includes(file.type)) {
        showError('Desteklenmeyen dosya formatı. Lütfen MP4, MOV, AVI, MKV veya WEBM formatında bir video yükleyin.');
        return;
    }

    // Validate file size (max 1GB)
    const maxSize = 1024 * 1024 * 1024; // 1GB
    if (file.size > maxSize) {
        showError(`Dosya çok büyük. Maksimum boyut: ${formatBytes(maxSize)}`);
        return;
    }

    selectedFile = file;
    displayFileInfo(file);
    uploadBtn.disabled = false;
}

function displayFileInfo(file) {
    fileInfo.classList.add('show');
    
    const fileDetailsHTML = `
        <div class="detail-item">
            <div class="detail-label">Dosya Adı</div>
            <div class="detail-value">${escapeHtml(file.name)}</div>
        </div>
        <div class="detail-item">
            <div class="detail-label">Boyut</div>
            <div class="detail-value">${formatBytes(file.size)}</div>
        </div>
        <div class="detail-item">
            <div class="detail-label">Tür</div>
            <div class="detail-value">${file.type || 'Bilinmiyor'}</div>
        </div>
        <div class="detail-item">
            <div class="detail-label">Son Değişiklik</div>
            <div class="detail-value">${new Date(file.lastModified).toLocaleDateString('tr-TR')}</div>
        </div>
    `;
    
    fileDetails.innerHTML = fileDetailsHTML;
}

function formatBytes(bytes, decimals = 2) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function showError(message) {
    alert(`Hata: ${message}`);
    resetForm();
}

function resetForm() {
    selectedFile = null;
    fileInput.value = '';
    fileInfo.classList.remove('show');
    uploadBtn.disabled = true;
    progressContainer.classList.remove('show');
    resultContainer.classList.remove('show');
    uploadInProgress = false;
    tagsInput.value = '';
    projectNameInput.value = '';
    notesInput.value = '';
    presetButtons[0].click(); // Reset to 720p
}

async function uploadVideo() {
    if (!selectedFile || uploadInProgress) return;
    
    uploadInProgress = true;
    uploadBtn.disabled = true;
    progressContainer.classList.add('show');
    
    try {
        // Step 1: Get presigned URL from API
        const presignedResponse = await fetch('/api/videos/upload/presigned', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-User-ID': 'demo-user' // Replace with actual user ID
            },
            body: JSON.stringify({
                fileName: selectedFile.name,
                fileSize: selectedFile.size,
                renderPreset: selectedPreset,
                tags: tagsInput.value,
                projectName: projectNameInput.value,
                notes: notesInput.value
            })
        });
        
        if (!presignedResponse.ok) {
            const errorData = await presignedResponse.json();
            throw new Error(errorData.error || 'Presigned URL alınamadı');
        }
        
        const presignedData = await presignedResponse.json();
        
        if (!presignedData.success) {
            throw new Error(presignedData.message || 'Presigned URL oluşturulamadı');
        }
        
        videoId = presignedData.video_id;
        const uploadUrl = presignedData.upload_url;
        const uploadToken = presignedData.upload_token;
        
        // Step 2: Direct upload to R2 using presigned URL
        const xhr = new XMLHttpRequest();
        
        xhr.upload.addEventListener('progress', (event) => {
            if (event.lengthComputable) {
                const percentComplete = (event.loaded / event.total) * 100;
                updateProgress(percentComplete);
            }
        });
        
        xhr.addEventListener('load', async () => {
            if (xhr.status >= 200 && xhr.status < 300) {
                try {
                    const uploadResult = JSON.parse(xhr.responseText);
                    
                    // Step 3: Notify server that upload is complete
                    const completeResponse = await fetch(`/api/videos/upload/complete/${uploadToken}`, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({
                            upload_successful: true,
                            actual_file_size: selectedFile.size
                        })
                    });
                    
                    if (!completeResponse.ok) {
                        throw new Error('Upload tamamlanamadı');
                    }
                    
                    const completeData = await completeResponse.json();
                    
                    if (!completeData.success) {
                        throw new Error(completeData.message || 'İşlem tamamlanamadı');
                    }
                    
                    // Show success result
                    showSuccessResult(completeData);
                    
                } catch (error) {
                    showError(`Upload tamamlanamadı: ${error.message}`);
                    resetForm();
                }
            } else {
                showError(`R2 upload hatası: ${xhr.status} ${xhr.statusText}`);
                resetForm();
            }
        });
        
        xhr.addEventListener('error', () => {
            showError('R2 upload bağlantı hatası');
            resetForm();
        });
        
        // Start upload
        xhr.open('PUT', uploadUrl, true);
        xhr.setRequestHeader('Content-Type', selectedFile.type || 'application/octet-stream');
        xhr.send(selectedFile);
        
    } catch (error) {
        showError(`Yükleme hatası: ${error.message}`);
        resetForm();
    }
}

function simulateProgress() {
    let progress = 0;
    const interval = setInterval(() => {
        if (progress >= 100) {
            clearInterval(interval);
            return;
        }
        
        progress += Math.random() * 10 + 5;
        if (progress > 100) progress = 100;
        
        updateProgress(progress);
        
        if (progress >= 100) {
            clearInterval(interval);
        }
    }, 200);
}

function updateProgress(percent) {
    progressFill.style.width = percent + '%';
    progressPercent.textContent = Math.round(percent) + '%';
}

function showSuccessResult(response) {
    resultContainer.classList.add('show');
    
    const normalizedName = response.normalized_name;
    const originalName = selectedFile.name;
    
    const resultHTML = `
        <div class="detail-item">
            <div class="detail-label">Video ID</div>
            <div class="detail-value">${response.video_id}</div>
        </div>
        <div class="detail-item">
            <div class="detail-label">Orijinal Ad</div>
            <div class="detail-value">${escapeHtml(originalName)}</div>
        </div>
        <div class="detail-item">
            <div class="detail-label">Normalize Edilmiş Ad</div>
            <div class="detail-value">${escapeHtml(normalizedName)}</div>
        </div>
        <div class="detail-item">
            <div class="detail-label">Render Preseti</div>
            <div class="detail-value">${selectedPreset === '720p_web' ? '720p Web Optimize' : '1080p Web Optimize'}</div>
        </div>
        <div class="detail-item">
            <div class="detail-label">Durum</div>
            <div class="detail-value">
                <span class="status-badge status-uploaded">Yüklendi</span>
            </div>
        </div>
        <div class="detail-item">
            <div class="detail-label">İşlem Sırası</div>
            <div class="detail-value">Sırada bekliyor</div>
        </div>
        <div class="detail-item">
            <div class="detail-label">Tahmini Süre</div>
            <div class="detail-value">~5-10 dakika</div>
        </div>
        <div class="video-preview">
            <h4>🎥 Video Önizleme</h4>
            <p>İşlem tamamlandığında video burada görüntülenecek.</p>
            <div style="background: #f1f5f9; padding: 40px; border-radius: 10px; margin-top: 15px;">
                <div style="font-size: 3rem; color: #94a3b8; margin-bottom: 15px;">⏳</div>
                <p style="color: #64748b;">Video işleniyor...</p>
            </div>
        </div>
    `;
    
    resultContent.innerHTML = resultHTML;
    
    // Start polling for status updates
    startStatusPolling(response.video_id);
}

function startStatusPolling(videoId) {
    let pollCount = 0;
    const maxPolls = 60; // Poll for 5 minutes (5 seconds interval)
    
    const pollInterval = setInterval(async () => {
        pollCount++;
        
        if (pollCount > maxPolls) {
            clearInterval(pollInterval);
            updateStatus('timeout', 'İşlem zaman aşımına uğradı');
            return;
        }
        
        try {
            // In real implementation, poll actual API
            // const response = await fetch(`/api/videos/${videoId}`);
            // const data = await response.json();
            
            // Simulate status progression
            let status, message;
            if (pollCount < 3) {
                status = 'uploaded';
                message = 'Yüklendi - sırada bekliyor';
            } else if (pollCount < 10) {
                status = 'processing';
                message = 'İşleniyor - Hetner sunucusunda';
            } else if (pollCount < 15) {
                status = 'processing';
                message = 'Handbrake ile encode ediliyor';
            } else if (pollCount < 20) {
                status = 'processing';
                message = 'R2\'ye yükleniyor';
            } else {
                status = 'completed';
                message = 'İşlem tamamlandı!';
                clearInterval(pollInterval);
            }
            
            updateStatus(status, message);
            
            if (status === 'completed') {
                showCompletedResult();
            }
            
        } catch (error) {
            console.error('Status polling error:', error);
        }
    }, 5000); // Poll every 5 seconds
}

function updateStatus(status, message) {
    const statusElement = document.querySelector('.status-badge');
    if (!statusElement) return;
    
    // Remove all status classes
    statusElement.classList.remove('status-uploaded', 'status-processing', 'status-completed', 'status-failed');
    
    // Add new status class
    statusElement.classList.add(`status-${status}`);
    
    // Update text
    const statusText = {
        'uploaded': 'Yüklendi',
        'processing': 'İşleniyor',
        'completed': 'Tamamlandı',
        'failed': 'Başarısız',
        'timeout': 'Zaman Aşımı'
    }[status] || status;
    
    statusElement.textContent = statusText;
    
    // Update status message if available
    const statusMessageElement = document.querySelector('.detail-item:nth-child(5) .detail-value');
    if (statusMessageElement) {
        const messageSpan = statusMessageElement.querySelector('span');
        if (messageSpan) {
            messageSpan.textContent = statusText;
        }
    }
}

function showCompletedResult() {
    const resultHTML = `
        <div class="detail-item">
            <div class="detail-label">Video ID</div>
            <div class="detail-value">${videoId}</div>
        </div>
        <div class="detail-item">
            <div class="detail-label">Durum</div>
            <div class="detail-value">
                <span class="status-badge status-completed">Tamamlandı</span>
            </div>
        </div>
        <div class="detail-item">
            <div class="detail-label">İşlem Süresi</div>
            <div class="detail-value">~2 dakika 45 saniye</div>
        </div>
        <div class="detail-item">
            <div class="detail-label">Boyut Azalması</div>
            <div class="detail-value">%35 (${formatBytes(selectedFile.size * 0.65)})</div>
        </div>
        <div class="video-preview">
            <h4>🎥 İşlenmiş Video</h4>
            <video controls style="max-width: 100%; border-radius: 10px;">
                <source src="https://r2.bilgekarga.com/perm/${videoId}/processed-video.mp4" type="video/mp4">
                Tarayıcınız video etiketini desteklemiyor.
            </video>
            <div style="margin-top: 15px; display: flex; gap: 10px; justify-content: center;">
                <button class="btn btn-primary" onclick="copyVideoLink()" style="padding: 10px 20px;">
                    📋 Linki Kopyala
                </button>
                <button class="btn btn-secondary" onclick="downloadVideo()" style="padding: 10px 20px;">
                    ⬇️ İndir
                </button>
            </div>
        </div>
        <div class="detail-item">
            <div class="detail-label">Kalıcı Link</div>
            <div class="detail-value">
                <input type="text" readonly value="https://r2.bilgekarga.com/perm/${videoId}/processed-video.mp4" 
                       style="width: 100%; padding: 8px; border: 1px solid #cbd5e1; border-radius: 5px; background: #f8fafc;">
            </div>
        </div>
    `;
    
    resultContent.innerHTML = resultHTML;
}

function copyVideoLink() {
    const link = `https://r2.bilgekarga.com/perm/${videoId}/processed-video.mp4`;
    navigator.clipboard.writeText(link).then(() => {
        alert('Video linki panoya kopyalandı!');
    }).catch(err => {
        console.error('Copy failed:', err);
        alert('Kopyalama başarısız. Lütfen linki manuel kopyalayın.');
    });
}

function downloadVideo() {
    const link = document.createElement('a');
    link.href = `https://r2.bilgekarga.com/perm/${videoId}/processed-video.mp4`;
    link.download = selectedFile.name.replace(/\.[^/.]+$/, '') + '-processed.mp4';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    console.log('Video Upload Interface loaded');
    
    // Add global reset function
    window.resetForm = resetForm;
    window.uploadVideo = uploadVideo;
    window.copyVideoLink = copyVideoLink;
    window.downloadVideo = downloadVideo;
});