#!/usr/bin/env python3
"""
BK-VF Hetner Python Agent - Multi-threaded Version
Atomic job processing with exponential backoff polling and multi-threading
Based on master JSON architecture from conversation with Claude

Features:
- Multi-threaded processing with ThreadPoolExecutor (max_workers=4)
- Exponential backoff polling with reset
- Atomic job claiming (race condition impossible)
- FFmpeg processing with -movflags +faststart (critical for e-commerce UX)
- Retry logic with exponential backoff
- Heartbeat monitoring
- Windows Service compatible (NSSM)
"""

import os
import sys
import time
import json
import logging
import subprocess
import requests
import uuid
import hashlib
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, List
from pathlib import Path
import tempfile
import shutil
import concurrent.futures
import threading
from queue import Queue, Empty
import signal

# yt-dlp için importlar (varsa)
try:
    import yt_dlp
    YT_DLP_AVAILABLE = True
except ImportError:
    YT_DLP_AVAILABLE = False
    print("Warning: yt-dlp not available. URL downloads will not work.")

# Configuration
CONFIG = {
    'api_base_url': os.getenv('BK_API_BASE_URL', 'https://api.bilgekarga.tr'),
    'bearer_token': os.getenv('BK_BEARER_TOKEN', ''),
    'worker_id': os.getenv('BK_WORKER_ID', f'hetner-{uuid.uuid4().hex[:8]}'),
    'ffmpeg_path': os.getenv('FFMPEG_PATH', 'ffmpeg'),
    'temp_dir': os.getenv('TEMP_DIR', 'C:/temp/video-processing'),
    
    # Multi-threading configuration
    'max_workers': int(os.getenv('MAX_WORKERS', '4')),
    'max_jobs_per_worker': int(os.getenv('MAX_JOBS_PER_WORKER', '1')),
    
    # Polling configuration
    'polling_base_interval': int(os.getenv('POLLING_BASE_INTERVAL', '10')),
    'polling_max_interval': int(os.getenv('POLLING_MAX_INTERVAL', '120')),
    'idle_threshold': int(os.getenv('IDLE_THRESHOLD', '5')),
    
    # Processing configuration
    'max_file_size': int(os.getenv('MAX_FILE_SIZE', '157286400')),  # 150MB
    'timeout_minutes': int(os.getenv('TIMEOUT_MINUTES', '60')),
    'delete_temp_files': os.getenv('DELETE_TEMP_FILES', 'true').lower() == 'true',
    
    # FFmpeg presets
    'ffmpeg_720p_preset': '-c:v libx264 -preset fast -crf 23 -profile:v high -level 4.1 -movflags +faststart -c:a aac -b:a 128k -vf scale=-2:720',
    'ffmpeg_1080p_preset': '-c:v libx264 -preset fast -crf 23 -profile:v high -level 4.1 -movflags +faststart -c:a aac -b:a 128k -vf scale=-2:1080',
    
    # R2 configuration
    'r2_raw_bucket': os.getenv('R2_RAW_BUCKET', 'raw-uploads'),
    'r2_public_bucket': os.getenv('R2_PUBLIC_BUCKET', 'public-videos'),
    'cdn_base_url': os.getenv('CDN_BASE_URL', 'https://r2.bilgekarga.com'),
    
    # Logging
    'log_level': os.getenv('LOG_LEVEL', 'INFO'),
    'log_file': os.getenv('LOG_FILE', 'C:/logs/bk-vf-agent-multi.log'),
    
    # Heartbeat
    'heartbeat_interval': int(os.getenv('HEARTBEAT_INTERVAL', '30')),
}

# Setup logging
logging.basicConfig(
    level=getattr(logging, CONFIG['log_level']),
    format='%(asctime)s - %(threadName)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(CONFIG['log_file']),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class WorkerThread(threading.Thread):
    """Worker thread for processing jobs"""
    
    def __init__(self, worker_id, agent, job_queue):
        super().__init__(name=f"Worker-{worker_id}")
        self.worker_id = worker_id
        self.agent = agent
        self.job_queue = job_queue
        self.running = True
        self.current_job = None
        
    def run(self):
        """Main worker loop"""
        logger.info(f"Worker {self.worker_id} started")
        
        while self.running:
            try:
                # Get job from queue
                job = self.job_queue.get(timeout=1)
                if job is None:  # Sentinel value to stop
                    break
                
                self.current_job = job
                logger.info(f"Worker {self.worker_id} processing job {job['id']}")
                
                # Process the job
                success = self.agent.process_single_job(job, self.worker_id)
                
                if success:
                    logger.info(f"Worker {self.worker_id} completed job {job['id']}")
                else:
                    logger.error(f"Worker {self.worker_id} failed job {job['id']}")
                
                self.current_job = None
                self.job_queue.task_done()
                
            except Empty:
                continue  # No jobs available, continue waiting
            except Exception as e:
                logger.error(f"Worker {self.worker_id} error: {e}")
                if self.current_job:
                    self.agent.fail_job(self.current_job['id'], f"Worker error: {e}")
                self.current_job = None
        
        logger.info(f"Worker {self.worker_id} stopped")
    
    def stop(self):
        """Stop the worker thread"""
        self.running = False

class BKVFMultiThreadedAgent:
    """BK-VF Hetner Agent with multi-threading"""
    
    def __init__(self):
        self.worker_id = CONFIG['worker_id']
        self.api_base_url = CONFIG['api_base_url']
        self.bearer_token = CONFIG['bearer_token']
        self.ffmpeg_path = CONFIG['ffmpeg_path']
        self.temp_dir = Path(CONFIG['temp_dir'])
        self.temp_dir.mkdir(parents=True, exist_ok=True)
        
        # Multi-threading state
        self.max_workers = CONFIG['max_workers']
        self.job_queue = Queue()
        self.workers = []
        self.executor = concurrent.futures.ThreadPoolExecutor(max_workers=self.max_workers)
        
        # State
        self.idle_count = 0
        self.last_heartbeat = None
        self.running = True
        self.active_jobs = {}  # job_id -> worker_id
        
        # Thread safety
        self.lock = threading.Lock()
        
        # Validate configuration
        self._validate_config()
        
        logger.info(f"BK-VF Multi-threaded Agent initialized. Worker ID: {self.worker_id}")
        logger.info(f"Max workers: {self.max_workers}")
        logger.info(f"API Base URL: {self.api_base_url}")
        logger.info(f"Temp Directory: {self.temp_dir}")
    
    def _validate_config(self):
        """Validate configuration"""
        if not self.bearer_token:
            logger.error("Bearer token not configured. Set BK_BEARER_TOKEN environment variable.")
            sys.exit(1)
        
        # Check if ffmpeg is available
        try:
            result = subprocess.run([self.ffmpeg_path, '-version'], 
                                  capture_output=True, text=True, timeout=5)
            if result.returncode != 0:
                logger.error(f"FFmpeg not found or not working: {result.stderr}")
                sys.exit(1)
            logger.info(f"FFmpeg version: {result.stdout.splitlines()[0]}")
        except Exception as e:
            logger.error(f"Failed to check FFmpeg: {e}")
            sys.exit(1)
    
    def start_workers(self):
        """Start worker threads"""
        logger.info(f"Starting {self.max_workers} worker threads")
        
        for i in range(self.max_workers):
            worker = WorkerThread(i + 1, self, self.job_queue)
            worker.start()
            self.workers.append(worker)
        
        logger.info(f"Started {len(self.workers)} worker threads")
    
    def stop_workers(self):
        """Stop worker threads gracefully"""
        logger.info("Stopping worker threads...")
        
        # Send sentinel values to stop workers
        for _ in range(len(self.workers)):
            self.job_queue.put(None)
        
        # Wait for workers to finish
        for worker in self.workers:
            worker.join(timeout=10)
            if worker.is_alive():
                logger.warning(f"Worker {worker.worker_id} did not stop gracefully")
                worker.stop()
        
        logger.info("All worker threads stopped")
    
    def _make_api_request(self, method: str, endpoint: str, data: Optional[Dict] = None) -> Optional[Dict]:
        """Make authenticated API request"""
        url = f"{self.api_base_url}{endpoint}"
        headers = {
            'Authorization': f'Bearer {self.bearer_token}',
            'Content-Type': 'application/json',
            'User-Agent': f'BK-VF-Agent/{self.worker_id}'
        }
        
        try:
            if method == 'GET':
                response = requests.get(url, headers=headers, timeout=30)
            elif method == 'POST':
                response = requests.post(url, headers=headers, json=data, timeout=30)
            else:
                logger.error(f"Unsupported HTTP method: {method}")
                return None
            
            if response.status_code == 204:
                return None  # No content
            
            response.raise_for_status()
            return response.json() if response.content else None
            
        except requests.exceptions.RequestException as e:
            logger.error(f"API request failed: {e}")
            return None
        except json.JSONDecodeError as e:
            logger.error(f"Failed to parse JSON response: {e}")
            return None
    
    def send_heartbeat(self, status: str = 'ACTIVE'):
        """Send heartbeat to API"""
        try:
            # Count active jobs
            with self.lock:
                active_job_count = len(self.active_jobs)
            
            data = {
                'status': status,
                'active_jobs': active_job_count,
                'max_workers': self.max_workers,
                'queue_size': self.job_queue.qsize(),
                'ip_address': self._get_ip_address(),
                'version': '1.0.0'
            }
            
            response = self._make_api_request('POST', '/api/heartbeat', data)
            if response:
                self.last_heartbeat = datetime.now()
                logger.debug(f"Heartbeat sent: {status}, Active jobs: {active_job_count}")
            return response
        except Exception as e:
            logger.error(f"Failed to send heartbeat: {e}")
            return None
    
    def _get_ip_address(self) -> str:
        """Get local IP address"""
        try:
            import socket
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
            return ip
        except:
            return 'unknown'
    
    def claim_job(self) -> Optional[Dict]:
        """Claim a pending job (atomic operation)"""
        try:
            response = self._make_api_request('POST', '/api/jobs/claim')
            if response:
                logger.info(f"Claimed job: {response['id']} - {response['clean_name']}")
                self.idle_count = 0  # Reset idle count
                return response
            else:
                logger.debug("No pending jobs available")
                return None
        except Exception as e:
            logger.error(f"Failed to claim job: {e}")
            return None
    
    def process_single_job(self, job: Dict, worker_id: str) -> bool:
        """Process a single job (called by worker thread)"""
        try:
            # Mark job as active
            with self.lock:
                self.active_jobs[job['id']] = worker_id
            
            logger.info(f"Worker {worker_id} processing job {job['id']}: {job['clean_name']}")
            
            # Download raw file
            temp_input = self.temp_dir / f"input_{job['id']}_{worker_id}.mp4"
            if not self.download_file(job['download_url'], temp_input):
                self.fail_job(job['id'], "Failed to download raw file")
                return False
            
            # Process video
            result = self.process_video(job, temp_input, worker_id)
            if not result:
                self.fail_job(job['id'], "Video processing failed")
                return False
            
            # Complete job
            if not self.complete_job(job['id'], result):
                self.fail_job(job['id'], "Failed to complete job")
                return False
            
            return True
            
        except Exception as e:
            logger.error(f"Error processing job {job['id']}: {e}")
            self.fail_job(job['id'], f"Processing error: {e}")
            return False
        finally:
            # Remove from active jobs
            with self.lock:
                self.active_jobs.pop(job['id'], None)
            
            # Clean up temp files
            if CONFIG['delete_temp_files']:
                self.cleanup_temp_files(job['id'], worker_id)
    
    def download_file(self, url: str, destination: Path) -> bool:
        """Download file from URL"""
        try:
            logger.info(f"Downloading file from {url}")
            response = requests.get(url, stream=True, timeout=60)
            response.raise_for_status()
            
            with open(destination, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    f.write(chunk)
            
            logger.info(f"File downloaded: {destination} ({destination.stat().st_size} bytes)")
            return True
        except Exception as e:
            logger.error(f"Failed to download file: {e}")
            return False
    
    def process_video(self, job: Dict, input_file: Path, worker_id: str) -> Optional[Dict]:
        """Process video with FFmpeg"""
        try:
            # Determine output filename
            output_filename = f"{job['clean_name'].replace('.mp4', '')}_{worker_id}.mp4"
            output_file = self.temp_dir / output_filename
            
            # Get FFmpeg preset based on quality
            if job['quality'] == '1080p':
                ffmpeg_preset = CONFIG['ffmpeg_1080p_preset']
                target_resolution = '1920x1080'
            else:
                ffmpeg_preset = CONFIG['ffmpeg_720p_preset']
                target_resolution = '1280x720'
            
            # Build FFmpeg command
            ffmpeg_command = [
                self.ffmpeg_path,
                '-i', str(input_file),
                '-y'  # Overwrite output file
            ]
            
            # Add preset parameters
            ffmpeg_command.extend(ffmpeg_preset.split())
            ffmpeg_command.append(str(output_file))
            
            # Log the command
            command_str = ' '.join(ffmpeg_command)
            logger.info(f"Worker {worker_id} running FFmpeg command: {command_str}")
            
            # Run FFmpeg
            start_time = time.time()
            result = subprocess.run(
                ffmpeg_command,
                capture_output=True,
                text=True,
                timeout=CONFIG['timeout_minutes'] * 60
            )
            processing_time = time.time() - start_time
            
            if result.returncode != 0:
                logger.error(f"FFmpeg failed: {result.stderr}")
                return None
            
            # Get video metadata
            metadata = self.get_video_metadata(output_file)
            
            # Upload to R2 (simulated)
            r2_key = f"videos/{datetime.now().year}/{datetime.now().month:02d}/{output_filename}"
            public_url = f"{CONFIG['cdn_base_url']}/{CONFIG['r2_public_bucket']}/{r2_key}"
            
            logger.info(f"Worker {worker_id} uploaded to R2: {public_url}")
            
            # Prepare result
            return {
                'public_url': public_url,
                'file_size_output': output_file.stat().st_size,
                'duration': metadata.get('duration', 0),
                'processing_time_seconds': int(processing_time),
                'resolution': metadata.get('resolution', target_resolution),
                'bitrate': metadata.get('bitrate', 0),
                'codec': metadata.get('codec', 'h264'),
                'frame_rate': metadata.get('frame_rate', 30),
                'audio_codec': metadata.get('audio_codec', 'aac'),
                'audio_bitrate': metadata.get('audio_bitrate', 128),
                'ffmpeg_command': command_str,
                'ffmpeg_output': result.stdout + result.stderr
            }
            
        except subprocess.TimeoutExpired:
            logger.error(f"FFmpeg timeout after {CONFIG['timeout_minutes']} minutes")
            return None
        except Exception as e:
            logger.error(f"Video processing failed: {e}")
            return None
    
    def get_video_metadata(self, video_path: Path) -> Dict:
        """Get video metadata using FFprobe"""
        try:
            command = [
                'ffprobe',
                '-v', 'quiet',
                '-print_format', 'json',
                '-show_format',
                '-show_streams',
                str(video_path)
            ]
            
            result = subprocess.run(command, capture_output=True, text=True, timeout=10)
            if result.returncode != 0:
                return {}
            
            data = json.loads(result.stdout)
            
            metadata = {}
            
            # Get duration
            if 'format' in data and 'duration' in data['format']:
                metadata['duration'] = int(float(data['format']['duration']))
            
            # Get video stream info
            for stream in data.get('streams', []):
                if stream['codec_type'] == 'video':
                    metadata['resolution'] = f"{stream.get('width', 0)}x{stream.get('height', 0)}"
                    metadata['codec'] = stream.get('codec_name', '')
                    metadata['frame_rate'] = eval(stream.get('r_frame_rate', '30/1')) if '/' in stream.get('r_frame_rate', '30/1') else 30
                    metadata['bitrate'] = int(stream.get('bit_rate', 0)) // 1000 if stream.get('bit_rate') else 0
                
                elif stream['codec_type'] == 'audio':
                    metadata['audio_codec'] = stream.get('codec_name', '')
                    metadata['audio_bitrate'] = int(stream.get('bit_rate', 0)) // 1000 if stream.get('bit_rate') else 0
            
            return metadata
            
        except Exception as e:
            logger.warning(f"Failed to get video metadata: {e}")
            return {}
    
    def complete_job(self, job_id: int, result: Dict) -> bool:
        """Complete a job with retry logic"""
        max_retries = 5
        retry_delays = [1, 2, 4, 8, 16]
        
        for attempt in range(max_retries):
            try:
                data = {
                    'job_id': job_id,
                    'public_url': result['public_url'],
                    'file_size_output': result['file_size_output'],
                    'duration': result['duration'],
                    'processing_time_seconds': result['processing_time_seconds'],
                    'resolution': result['resolution'],
                    'bitrate': result['bitrate'],
                    'codec': result['codec'],
                    'frame_rate': result['frame_rate'],
                    'audio_codec': result['audio_codec'],
                    'audio_bitrate': result['audio_bitrate'],
                    'ffmpeg_command': result['ffmpeg_command'],
                    'ffmpeg_output': result['ffmpeg_output']
                }
                
                response = self._make_api_request('POST', '/api/jobs/complete', data)
                if response:
                    logger.info(f"Job {job_id} completed successfully")
                    return True
                else:
                    logger.warning(f"Failed to complete job {job_id} (attempt {attempt + 1}/{max_retries})")
                    
            except Exception as e:
                logger.error(f"Error completing job {job_id}: {e}")
            
            # Exponential backoff before retry
            if attempt < max_retries - 1:
                delay = retry_delays[attempt]
                logger.info(f"Retrying in {delay} seconds...")
                time.sleep(delay)
        
        logger.error(f"Failed to complete job {job_id} after {max_retries} attempts")
        return False
    
    def fail_job(self, job_id: int, error_message: str) -> bool:
        """Mark a job as failed"""
        try:
            data = {
                'job_id': job_id,
                'error_message': error_message
            }
            
            response = self._make_api_request('POST', '/api/jobs/fail', data)
            if response:
                logger.error(f"Job {job_id} marked as failed: {error_message}")
                return True
            return False
        except Exception as e:
            logger.error(f"Failed to mark job {job_id} as failed: {e}")
            return False
    
    def cleanup_temp_files(self, job_id: Optional[int] = None, worker_id: Optional[str] = None):
        """Clean up temporary files"""
        try:
            pattern = f"*_{job_id}_*" if job_id else "*"
            if worker_id and job_id:
                pattern = f"*_{job_id}_{worker_id}*"
            
            for file in self.temp_dir.glob(pattern):
                try:
                    if file.is_file():
                        file.unlink()
                except Exception as e:
                    logger.warning(f"Failed to delete {file}: {e}")
            
            logger.debug(f"Temporary files cleaned up for pattern: {pattern}")
        except Exception as e:
            logger.error(f"Failed to cleanup temp files: {e}")
    
    def run(self):
        """Main agent loop with exponential backoff polling"""
        logger.info("Starting BK-VF Multi-threaded Agent")
        
        # Start worker threads
        self.start_workers()
        
        # Register signal handlers for graceful shutdown
        def signal_handler(signum, frame):
            logger.info("Received shutdown signal")
            self.running = False
        
        signal.signal(signal.SIGINT, signal_handler)
        signal.signal(signal.SIGTERM, signal_handler)
        
        last_heartbeat_time = 0
        
        while self.running:
            try:
                # Send heartbeat periodically
                current_time = time.time()
                if current_time - last_heartbeat_time >= CONFIG['heartbeat_interval']:
                    self.send_heartbeat()
                    last_heartbeat_time = current_time
                
                # Check if we can process more jobs
                with self.lock:
                    current_active = len(self.active_jobs)
                
                if current_active < self.max_workers:
                    # Claim a job
                    job = self.claim_job()
                    
                    if job:
                        # Add job to queue for processing
                        self.job_queue.put(job)
                        logger.info(f"Job {job['id']} added to queue. Active: {current_active + 1}/{self.max_workers}")
                    else:
                        # No jobs available, increment idle count
                        self.idle_count += 1
                        logger.debug(f"No jobs available. Idle count: {self.idle_count}")
                else:
                    # All workers busy
                    logger.debug(f"All workers busy. Active: {current_active}/{self.max_workers}")
                
                # Calculate wait time with exponential backoff
                if self.idle_count >= CONFIG['idle_threshold']:
                    # Exponential backoff with cap
                    wait_time = min(
                        CONFIG['polling_base_interval'] * (2 ** min(self.idle_count - CONFIG['idle_threshold'], 4)),
                        CONFIG['polling_max_interval']
                    )
                else:
                    wait_time = CONFIG['polling_base_interval']
                
                # Wait before next poll
                logger.debug(f"Waiting {wait_time} seconds before next poll")
                time.sleep(wait_time)
                
            except Exception as e:
                logger.error(f"Error in main loop: {e}")
                time.sleep(CONFIG['polling_base_interval'])
        
        # Shutdown gracefully
        logger.info("Shutting down agent...")
        self.stop_workers()
        self.cleanup_temp_files()
        logger.info("Agent shutdown complete")

def main():
    """Main entry point"""
    agent = BKVFMultiThreadedAgent()
    agent.run()

if __name__ == '__main__':
    main()