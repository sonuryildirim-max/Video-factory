/**
 * Job Repository for BK-VF (Bilge Karga Video Factory)
 * Handles all conversion_jobs database operations
 */

export class JobRepository {
    constructor(env) {
        this.env = env;
        this.db = env.DB;
        this.kv = env.VIDEO_STATS_KV;
    }

    /**
     * Create a new conversion job
     * @param {Object} jobData - Job data
     * @returns {Promise<Object>} Created job
     */
    async create(jobData) {
        const {
            original_name,
            clean_name,
            r2_raw_key,
            quality,
            file_size_input,
            uploaded_by,
            tags,
            project_name,
            notes
        } = jobData;

        const result = await this.db.prepare(`
            INSERT INTO conversion_jobs (
                original_name, clean_name, r2_raw_key, quality, 
                file_size_input, uploaded_by, tags, project_name, notes
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        `).bind(
            original_name,
            clean_name,
            r2_raw_key,
            quality,
            file_size_input || 0,
            uploaded_by || 'admin',
            tags || '',
            project_name || '',
            notes || ''
        ).run();

        const jobId = result.meta.last_row_id;
        return this.getById(jobId);
    }

    /**
     * Claim a pending job (atomic operation)
     * @param {string} workerId - Worker identifier
     * @returns {Promise<Object|null>} Claimed job or null if no jobs available
     */
    async claimPendingJob(workerId) {
        // Find a PENDING job and atomically update to PROCESSING
        const result = await this.db.prepare(`
            UPDATE conversion_jobs
            SET 
                status = 'PROCESSING',
                worker_id = ?,
                started_at = CURRENT_TIMESTAMP,
                retry_count = 0
            WHERE id = (
                SELECT id FROM conversion_jobs
                WHERE status = 'PENDING'
                ORDER BY created_at ASC
                LIMIT 1
            )
            RETURNING *
        `).bind(workerId).first();

        return result || null;
    }

    /**
     * Complete a job
     * @param {number} jobId - Job ID
     * @param {string} workerId - Worker identifier
     * @param {Object} resultData - Processing result data
     * @returns {Promise<Object>} Updated job
     */
    async completeJob(jobId, workerId, resultData) {
        const {
            public_url,
            file_size_output,
            duration,
            processing_time_seconds,
            resolution,
            bitrate,
            codec,
            frame_rate,
            audio_codec,
            audio_bitrate,
            ffmpeg_command,
            ffmpeg_output
        } = resultData;

        const result = await this.db.prepare(`
            UPDATE conversion_jobs
            SET 
                status = 'COMPLETED',
                public_url = ?,
                file_size_output = ?,
                duration = ?,
                processing_time_seconds = ?,
                resolution = ?,
                bitrate = ?,
                codec = ?,
                frame_rate = ?,
                audio_codec = ?,
                audio_bitrate = ?,
                ffmpeg_command = ?,
                ffmpeg_output = ?,
                completed_at = CURRENT_TIMESTAMP
            WHERE id = ? AND worker_id = ?
            RETURNING *
        `).bind(
            public_url,
            file_size_output || 0,
            duration || 0,
            processing_time_seconds || 0,
            resolution || '',
            bitrate || 0,
            codec || 'h264',
            frame_rate || 30,
            audio_codec || 'aac',
            audio_bitrate || 128,
            ffmpeg_command || '',
            ffmpeg_output || '',
            jobId,
            workerId
        ).first();

        if (!result) {
            throw new Error(`Job ${jobId} not found or not owned by worker ${workerId}`);
        }

        // Update KV store statistics asynchronously
        this.updateStatisticsInKV('completed');

        return result;
    }

    /**
     * Fail a job
     * @param {number} jobId - Job ID
     * @param {string} workerId - Worker identifier
     * @param {Object} failData - Failure data
     * @returns {Promise<Object>} Updated job
     */
    async failJob(jobId, workerId, failData) {
        const {
            error_message,
            retry_count,
            status
        } = failData;

        const result = await this.db.prepare(`
            UPDATE conversion_jobs
            SET 
                status = ?,
                error_message = ?,
                retry_count = ?,
                completed_at = CURRENT_TIMESTAMP
            WHERE id = ? AND worker_id = ?
            RETURNING *
        `).bind(
            status,
            error_message,
            retry_count || 0,
            jobId,
            workerId
        ).first();

        if (!result) {
            throw new Error(`Job ${jobId} not found or not owned by worker ${workerId}`);
        }

        // Update KV store statistics asynchronously
        if (status === 'FAILED') {
            this.updateStatisticsInKV('failed');
        }

        return result;
    }

    /**
     * Get job by ID
     * @param {number} jobId - Job ID
     * @returns {Promise<Object|null>} Job or null if not found
     */
    async getById(jobId) {
        return await this.db.prepare(`
            SELECT * FROM conversion_jobs
            WHERE id = ?
        `).bind(jobId).first();
    }

    /**
     * Get jobs with filters
     * @param {Object} filters - Filter criteria
     * @returns {Promise<Array>} Filtered jobs
     */
    async getJobs(filters = {}) {
        const {
            status,
            quality,
            uploaded_by,
            search,
            start_date,
            end_date,
            page = 1,
            limit = 50,
            sort_by = 'created_at',
            sort_order = 'DESC'
        } = filters;

        const whereClauses = [];
        const params = [];

        if (status) {
            whereClauses.push('status = ?');
            params.push(status);
        }

        if (quality) {
            whereClauses.push('quality = ?');
            params.push(quality);
        }

        if (uploaded_by) {
            whereClauses.push('uploaded_by = ?');
            params.push(uploaded_by);
        }

        if (search) {
            whereClauses.push('(original_name LIKE ? OR clean_name LIKE ? OR tags LIKE ? OR project_name LIKE ? OR notes LIKE ?)');
            const searchLike = `%${search}%`;
            params.push(searchLike, searchLike, searchLike, searchLike, searchLike);
        }

        if (start_date) {
            whereClauses.push('created_at >= ?');
            params.push(start_date + 'T00:00:00');
        }

        if (end_date) {
            whereClauses.push('created_at <= ?');
            params.push(end_date + 'T23:59:59.999Z');
        }

        const whereSQL = whereClauses.length > 0 ? ' WHERE ' + whereClauses.join(' AND ') : '';

        // Count total
        const countResult = await this.db.prepare(`
            SELECT COUNT(*) as total FROM conversion_jobs${whereSQL}
        `).bind(...params).first();

        const totalCount = countResult.total || 0;
        const totalPages = Math.ceil(totalCount / limit) || 1;
        const offset = (page - 1) * limit;

        // Validate sort column
        const validSortColumns = ['created_at', 'started_at', 'completed_at', 'file_size_input', 'processing_time_seconds'];
        const sortColumn = validSortColumns.includes(sort_by) ? sort_by : 'created_at';
        const sortOrder = sort_order.toUpperCase() === 'ASC' ? 'ASC' : 'DESC';

        // Get data
        const dataResult = await this.db.prepare(`
            SELECT * FROM conversion_jobs${whereSQL}
            ORDER BY ${sortColumn} ${sortOrder}
            LIMIT ? OFFSET ?
        `).bind(...params, limit, offset).all();

        return {
            jobs: dataResult.results || [],
            totalCount,
            page,
            totalPages,
            limit
        };
    }

    /**
     * Get timed out jobs
     * @param {number} timeoutMinutes - Timeout in minutes
     * @returns {Promise<Array>} Timed out jobs
     */
    async getTimedOutJobs(timeoutMinutes) {
        return await this.db.prepare(`
            SELECT * FROM conversion_jobs
            WHERE status = 'PROCESSING'
            AND started_at < datetime('now', '-' || ? || ' minutes')
        `).bind(timeoutMinutes).all();
    }

    /**
     * Get recent activity
     * @param {number} days - Number of days
     * @returns {Promise<Array>} Recent activity
     */
    async getRecentActivity(days = 7) {
        return await this.db.prepare(`
            SELECT 
                DATE(created_at) as date,
                COUNT(*) as total_jobs,
                SUM(CASE WHEN status = 'COMPLETED' THEN 1 ELSE 0 END) as completed,
                SUM(CASE WHEN status = 'FAILED' THEN 1 ELSE 0 END) as failed
            FROM conversion_jobs
            WHERE created_at >= datetime('now', '-' || ? || ' days')
            GROUP BY DATE(created_at)
            ORDER BY date DESC
        `).bind(days).all();
    }

    /**
     * Get top uploaders
     * @param {number} limit - Limit
     * @returns {Promise<Array>} Top uploaders
     */
    async getTopUploaders(limit = 5) {
        return await this.db.prepare(`
            SELECT 
                uploaded_by,
                COUNT(*) as job_count,
                SUM(file_size_input) as total_size_input
            FROM conversion_jobs
            WHERE created_at >= datetime('now', '-30 days')
            GROUP BY uploaded_by
            ORDER BY job_count DESC
            LIMIT ?
        `).bind(limit).all();
    }

    /**
     * Get daily statistics
     * @param {number} days - Number of days
     * @returns {Promise<Array>} Daily statistics
     */
    async getDailyStatistics(days = 30) {
        return await this.db.prepare(`
            SELECT 
                date,
                total_jobs,
                completed_jobs,
                failed_jobs,
                pending_jobs,
                total_input_size_bytes,
                total_output_size_bytes,
                avg_processing_time_seconds,
                quality_720p_count,
                quality_1080p_count,
                top_uploader
            FROM daily_statistics
            WHERE date >= date('now', '-' || ? || ' days')
            ORDER BY date DESC
        `).bind(days).all();
    }

    /**
     * Get general statistics
     * @returns {Promise<Object>} Statistics
     */
    async getStatistics() {
        const result = await this.db.prepare(`
            SELECT 
                COUNT(*) as total_jobs,
                SUM(CASE WHEN status = 'COMPLETED' THEN 1 ELSE 0 END) as completed_jobs,
                SUM(CASE WHEN status = 'FAILED' THEN 1 ELSE 0 END) as failed_jobs,
                SUM(CASE WHEN status = 'PENDING' THEN 1 ELSE 0 END) as pending_jobs,
                SUM(CASE WHEN status = 'PROCESSING' THEN 1 ELSE 0 END) as processing_jobs,
                SUM(file_size_input) as total_input_size,
                SUM(file_size_output) as total_output_size,
                AVG(processing_time_seconds) as avg_processing_time,
                SUM(CASE WHEN quality = '720p' THEN 1 ELSE 0 END) as quality_720p_count,
                SUM(CASE WHEN quality = '1080p' THEN 1 ELSE 0 END) as quality_1080p_count
            FROM conversion_jobs
        `).first();

        return result || {
            total_jobs: 0,
            completed_jobs: 0,
            failed_jobs: 0,
            pending_jobs: 0,
            processing_jobs: 0,
            total_input_size: 0,
            total_output_size: 0,
            avg_processing_time: 0,
            quality_720p_count: 0,
            quality_1080p_count: 0
        };
    }

    /**
     * Update worker heartbeat
     * @param {string} workerId - Worker identifier
     * @param {Object} heartbeatData - Heartbeat data
     * @returns {Promise<Object>} Updated heartbeat
     */
    async updateWorkerHeartbeat(workerId, heartbeatData) {
        const {
            status,
            current_job_id,
            ip_address,
            version
        } = heartbeatData;

        // Insert or update heartbeat
        const result = await this.db.prepare(`
            INSERT OR REPLACE INTO worker_heartbeats 
            (worker_id, last_heartbeat, status, current_job_id, ip_address, version)
            VALUES (?, CURRENT_TIMESTAMP, ?, ?, ?, ?)
            RETURNING *
        `).bind(
            workerId,
            status || 'ACTIVE',
            current_job_id || null,
            ip_address || '',
            version || '1.0.0'
        ).first();

        return result;
    }

    /**
     * Update statistics in KV store (async, non-blocking)
     * @param {string} eventType - Event type (completed, failed)
     */
    async updateStatisticsInKV(eventType) {
        try {
            if (!this.kv) return;

            const today = new Date().toISOString().slice(0, 10);
            const key = `video_stats:${today}`;

            // Get current stats
            let stats = await this.kv.get(key, 'json');
            if (!stats) {
                stats = {
                    date: today,
                    total_jobs: 0,
                    completed_jobs: 0,
                    failed_jobs: 0,
                    pending_jobs: 0,
                    total_input_size_bytes: 0,
                    total_output_size_bytes: 0,
                    avg_processing_time_seconds: 0,
                    quality_720p_count: 0,
                    quality_1080p_count: 0
                };
            }

            // Update counters
            stats.total_jobs += 1;
            if (eventType === 'completed') {
                stats.completed_jobs += 1;
            } else if (eventType === 'failed') {
                stats.failed_jobs += 1;
            }

            // Save back to KV
            await this.kv.put(key, JSON.stringify(stats), {
                expirationTtl: 86400 * 30 // 30 days
            });

            console.log(`Updated KV statistics for ${today}: ${eventType}`);

        } catch (error) {
            console.error('Error updating KV statistics:', error);
            // Non-critical, continue
        }
    }

    /**
     * Search jobs using FTS5 full-text search
     * @param {string} query - Search query
     * @param {Object} filters - Additional filters
     * @returns {Promise<Array>} Search results
     */
    async searchWithFTS(query, filters = {}) {
        const { page = 1, limit = 50 } = filters;

        // First, create FTS5 virtual table if not exists
        await this.createFTS5TableIfNeeded();

        // Search using FTS5
        const ftsResults = await this.db.prepare(`
            SELECT job_id, rank
            FROM conversion_jobs_fts
            WHERE conversion_jobs_fts MATCH ?
            ORDER BY rank
            LIMIT ? OFFSET ?
        `).bind(query, limit, (page - 1) * limit).all();

        if (!ftsResults.results || ftsResults.results.length === 0) {
            return {
                jobs: [],
                totalCount: 0,
                page,
                totalPages: 0,
                limit
            };
        }

        // Get job IDs from FTS results
        const jobIds = ftsResults.results.map(r => r.job_id);
        const placeholders = jobIds.map(() => '?').join(',');

        // Get full job details
        const jobsResult = await this.db.prepare(`
            SELECT * FROM conversion_jobs
            WHERE id IN (${placeholders})
            ORDER BY FIELD(id, ${placeholders})
        `).bind(...jobIds, ...jobIds).all();

        // Count total (approximate for FTS)
        const countResult = await this.db.prepare(`
            SELECT COUNT(*) as total
            FROM conversion_jobs_fts
            WHERE conversion_jobs_fts MATCH ?
        `).bind(query).first();

        const totalCount = countResult.total || 0;
        const totalPages = Math.ceil(totalCount / limit) || 1;

        return {
            jobs: jobsResult.results || [],
            totalCount,
            page,
            totalPages,
            limit
        };
    }

    /**
     * Create FTS5 virtual table if needed
     */
    async createFTS5TableIfNeeded() {
        // Check if table exists
        try {
            await this.db.prepare(`
                SELECT 1 FROM conversion_jobs_fts LIMIT 1
            `).run();
        } catch (error) {
            // Table doesn't exist, create it
            await this.db.prepare(`
                CREATE VIRTUAL TABLE IF NOT EXISTS conversion_jobs_fts
                USING fts5(
                    job_id UNINDEXED,
                    original_name,
                    clean_name,
                    tags,
                    project_name,
                    notes,
                    content='conversion_jobs',
                    content_rowid='id'
                )
            `).run();

            // Populate initial data
            await this.db.prepare(`
                INSERT INTO conversion_jobs_fts (rowid, job_id, original_name, clean_name, tags, project_name, notes)
                SELECT id, id, original_name, clean_name, tags, project_name, notes
                FROM conversion_jobs
            `).run();

            console.log('FTS5 table created and populated');
        }
    }

    /**
     * Update FTS5 index for a specific job
     * @param {number} jobId - Job ID
     */
    async updateFTSIndex(jobId) {
        try {
            await this.createFTS5TableIfNeeded();

            const job = await this.getById(jobId);
            if (!job) return;

            // Update or insert into FTS table
            await this.db.prepare(`
                INSERT OR REPLACE INTO conversion_jobs_fts (rowid, job_id, original_name, clean_name, tags, project_name, notes)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            `).bind(
                jobId,
                jobId,
                job.original_name || '',
                job.clean_name || '',
                job.tags || '',
                job.project_name || '',
                job.notes || ''
            ).run();

        } catch (error) {
            console.error('Error updating FTS index:', error);
        }
    }
}