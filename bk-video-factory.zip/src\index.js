/**
 * Bilge Karga Link Hub v2.0
 * Main Entry Point
 */

import { routeRequest } from './routes/index.js';
import { SECURITY_HEADERS } from './config/constants.js';
import { handleCORS } from './middleware/cors.js';
import { handleError } from './utils/errors.js';

export default {
    async fetch(request, env, ctx) {
        try {
            // Handle CORS preflight
            if (request.method === 'OPTIONS') {
                return handleCORS(request, env);
            }

            // Route request
            const response = await routeRequest(request, env, ctx);

            // Add security headers to all responses
            const headers = new Headers(response.headers);
            Object.entries(SECURITY_HEADERS).forEach(([key, value]) => {
                headers.set(key, value);
            });

            return new Response(response.body, {
                status: response.status,
                statusText: response.statusText,
                headers: headers
            });

        } catch (error) {
            return handleError(error, request);
        }
    }
};
